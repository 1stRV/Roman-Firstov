package ru.x5.markusdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarkusdataApplication {

    public static void main(String[] args) {
        SpringApplication.run(MarkusdataApplication.class, args);
    }

}
