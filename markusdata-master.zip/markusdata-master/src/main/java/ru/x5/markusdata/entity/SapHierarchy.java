
package ru.x5.markusdata.entity;

import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.Id;

@Entity
@Data
public class SapHierarchy {

    @JsonProperty("LEV4_CODE")
    @Id
    private String lev4Code;
    @JsonProperty("LEV1")
    private String lev1;
    @JsonProperty("LEV1_CODE")
    private String lev1Code;
    @JsonProperty("LEV2")
    private String lev2;
    @JsonProperty("LEV2_CODE")
    private String lev2Code;
    @JsonProperty("LEV3")
    private String lev3;
    @JsonProperty("LEV3_CODE")
    private String lev3Code;
    @JsonProperty("LEV4")
    private String lev4;
    @JsonProperty("LEV5")
    private String lev5;
    @JsonProperty("LEV5_CODE")
    private String lev5Code;
    @JsonProperty("LEV6")
    private String lev6;
    @JsonProperty("LEV6_CODE")
    private String lev6Code;

}
