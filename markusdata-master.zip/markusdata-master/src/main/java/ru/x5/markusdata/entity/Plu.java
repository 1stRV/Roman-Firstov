
package ru.x5.markusdata.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Entity
@Data
public class Plu {

    @Id
    @JsonProperty("PLU_ID")
    private String pluId;
    @JsonProperty("BASE_UNIT")
    private String baseUnit;
    @JsonProperty("CRT_DATE")
    private String crtDate;
    @JsonProperty("CRT_USER")
    private String crtUser;
    @JsonProperty("EAN18")
    private String ean18;
    @JsonProperty("EANS")
    private String eans;
    @JsonProperty("EDIT_DATE")
    private String editDate;
    @JsonProperty("EDIT_USER")
    private String editUser;
    @JsonProperty("FIN_CODE")
    private String finCode;
    @JsonProperty("FULLNAME")
    private String fullName;
    @JsonProperty("ID")
    private String id;
    @JsonProperty("IS_TECH_PLU")
    private String isTechPlu;
    @JsonProperty("MRC")
    private String mrc;

    @OneToOne(cascade= CascadeType.ALL)
    @JoinColumn(name="packageId", referencedColumnName="packageId")
    @JsonProperty("PACKAGING")
    private Packaging packaging;
    @JsonProperty("PLU_ID_INT")
    private String pluIdInt;
    @JsonProperty("PRODUCT_TYPE_CLASS1")
    private String productTypeClass1;
    @JsonProperty("PRODUCT_TYPE_CLASS2")
    private String productTypeClass2;
    @JsonProperty("PRODUCT_TYPE_CLASS3")
    private String productTypeClass3;
    @JsonProperty("PRODUCT_TYPE_CLASS4")
    private String productTypeClass4;
    @JsonProperty("PRODUCT_TYPE_CLASS5")
    private String productTypeClass5;
    @JsonProperty("PRODUCT_TYPE_CLASS6")
    private String productTypeClass6;
    @JsonProperty("PRODUCT_TYPE_CLASS_CODE")
    private String productTypeClassCode;
    @JsonProperty("PRODUCT_TYPE_CLASS_NAME1")
    private String productTypeClassName1;
    @JsonProperty("PRODUCT_TYPE_CLASS_NAME2")
    private String productTypeClassName2;
    @JsonProperty("PRODUCT_TYPE_CLASS_NAME3")
    private String productTypeClassName3;
    @JsonProperty("PRODUCT_TYPE_CLASS_NAME4")
    private String productTypeClassName4;
    @JsonProperty("PRODUCT_TYPE_CLASS_NAME5")
    private String productTypeClassName5;
    @JsonProperty("PRODUCT_TYPE_CLASS_NAME6")
    private String productTypeClassName6;
    @JsonProperty("TABACCO")
    private String tabacco;

    @OneToOne(cascade= CascadeType.ALL)
    @JoinColumn(name="sapHierarchy", referencedColumnName="lev4Code")
    @JsonProperty("SapHierarchy")
    private SapHierarchy sapHierarchy;
    @JsonProperty("UI4CODE")
    private String ui4Code;
    @JsonProperty("UNITS_IN_PACKAGING")
    private String unitsInPackaging;

}
