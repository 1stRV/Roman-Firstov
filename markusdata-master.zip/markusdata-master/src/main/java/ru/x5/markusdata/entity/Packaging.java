
package ru.x5.markusdata.entity;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
@Data
public class Packaging {

    @JsonProperty("PACKAGE_ID")
    @Id
    private String packageId;

    @JsonProperty("AMOUNT_IN_PACKAGE")
    private String amountInPackage;

    @OneToOne(cascade= CascadeType.ALL)
    @JoinColumn(name="gtins", referencedColumnName="gtin")
    @JsonProperty("GTINS")
    private Gtins gtins;

    @JsonProperty("HWD_UNIT")
    private String hwdUnit;

    @JsonProperty("IS_SHOWBOX")
    private String isShowBox;

    @JsonProperty("LOCAL_PACK")
    private String localPack;

    @JsonProperty("PACKAGE_CH_ID")
    private String packageChId;

    @JsonProperty("PACKAGE_CODE")
    private String packageCode;

    @JsonProperty("PACKAGE_TYPE")
    private String packageType;

    @JsonProperty("SALES_PACKING")
    private String salesPacking;

    @JsonProperty("UNITS_IN_PACKAGING")
    private String unitsInPackaging;

}
