package ru.x5.markusdata.repository;

import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.x5.markusdata.entity.dto.WarehouseDTO;
import ru.x5.markusdata.entity.jpa.Warehouse;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class WarehouseRepositoryIntegrationTest extends AbstractRepositoryTest {
    @Autowired
    private WarehouseRepository warehouseRestRepository;

    @Value("classpath:json/warehouse.json")
    private Resource warehouseInsertRequestResource;

    @Value("classpath:json/warehouse-change.json")
    private Resource warehouseUpdateRequestResource;

    @Value("classpath:json/warehouse-long-field.json")
    private Resource warehouseLongFieldRequestResource;

    @Value("classpath:json/warehouse-inn-null-field.json")
    private Resource warehouseNullFieldRequestResource;


    @Value("classpath:json/balance-unit.json")
    private Resource balanceUnitInsertRequestResource;

    private String warehouseInsertRequest;

    private String warehouseUpdateRequest;

    private String warehouseLongFieldRequest;

    private String warehouseNullFieldRequest;

    private String balanceUnitInsertRequest;

    @Before
    public void init() throws IOException {
        balanceUnitInsertRequest = IOUtils.toString(balanceUnitInsertRequestResource.getInputStream(), StandardCharsets.UTF_8);
        warehouseInsertRequest = IOUtils.toString(warehouseInsertRequestResource.getInputStream(), StandardCharsets.UTF_8);
        warehouseUpdateRequest = IOUtils.toString(warehouseUpdateRequestResource.getInputStream(), StandardCharsets.UTF_8);
        warehouseLongFieldRequest = IOUtils.toString(warehouseLongFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
        warehouseNullFieldRequest = IOUtils.toString(warehouseNullFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
    }

    @Test
    public void warehouseRepositoryInsert() throws Exception {
        restTemplate.postForEntity("/balanceUnit", balanceUnitInsertRequest, Object.class);
        WarehouseDTO warehouseInsertExpected = objectMapper.readValue(warehouseInsertRequest, WarehouseDTO.class);
        ResponseEntity responseEntityInsert = restTemplate.postForEntity("/warehouse", warehouseInsertRequest, Object.class);
        assertEquals(HttpStatus.OK, responseEntityInsert.getStatusCode());

        Optional<Warehouse> optionalWarehouse = warehouseRestRepository.findById(warehouseInsertExpected.getMdmId());
        assertTrue(optionalWarehouse.isPresent());
        Assertions.assertThat(warehouseInsertExpected).isEqualToIgnoringGivenFields(optionalWarehouse.get(), "LAST_MOD_DATE", "FIRST_ADD_DATE");
    }

    @Test
    public void warehouseRepositoryUpdate() throws Exception {
        restTemplate.postForEntity("/balanceUnit", balanceUnitInsertRequest, Object.class);
        restTemplate.postForEntity("/warehouse", warehouseInsertRequest, Object.class);

        WarehouseDTO warehouseUpdateExpected = objectMapper.readValue(warehouseUpdateRequest, WarehouseDTO.class);
        ResponseEntity responseEntityUpdate = restTemplate.postForEntity("/warehouse", warehouseUpdateRequest, Object.class);
        assertEquals(HttpStatus.OK, responseEntityUpdate.getStatusCode());

        Optional<Warehouse> optionalWarehouse = warehouseRestRepository.findById(warehouseUpdateExpected.getMdmId());
        assertTrue(optionalWarehouse.isPresent());
        Assertions.assertThat(warehouseUpdateExpected).isEqualToIgnoringGivenFields(optionalWarehouse.get(), "LAST_MOD_DATE", "FIRST_ADD_DATE");
    }

    @Test
    public void longFieldRequest() {
        restTemplate.postForEntity("/balanceUnit", balanceUnitInsertRequest, Object.class);
        ResponseEntity responseEntity = restTemplate.postForEntity("/warehouse", warehouseLongFieldRequest, Object.class);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }

    @Test
    public void nullFieldRequest() {
        restTemplate.postForEntity("/balanceUnit", balanceUnitInsertRequest, Object.class);
        ResponseEntity responseEntity = restTemplate.postForEntity("/warehouse", warehouseNullFieldRequest, Object.class);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }
}