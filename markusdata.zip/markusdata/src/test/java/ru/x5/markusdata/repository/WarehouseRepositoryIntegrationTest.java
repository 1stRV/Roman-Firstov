package ru.x5.markusdata.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.x5.markusdata.entity.dto.WarehouseDTO;
import ru.x5.markusdata.entity.jpa.Warehouse;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

public class WarehouseRepositoryIntegrationTest extends AbstractRepositoryTest {
    @Autowired
    private WarehouseRepository warehouseRestRepository;

    @Value("classpath:json/warehouse.json")
    private Resource warehouseInsertRequestResource;

    @Value("classpath:json/warehouse-change.json")
    private Resource warehouseUpdateRequestResource;

    @Value("classpath:json/warehouse-long-field.json")
    private Resource warehouseLongFieldRequestResource;

    @Value("classpath:json/warehouse-inn-null-field.json")
    private Resource warehouseNullFieldRequestResource;


    @Value("classpath:json/balance-unit.json")
    private Resource balanceUnitInsertRequestResource;

    private String warehouseInsertRequest;

    private String warehouseUpdateRequest;

    private String warehouseLongFieldRequest;

    private String warehouseNullFieldRequest;

    private String balanceUnitInsertRequest;

    @Before
    public void init() throws IOException {
        balanceUnitInsertRequest = IOUtils.toString(balanceUnitInsertRequestResource.getInputStream(), StandardCharsets.UTF_8);
        warehouseInsertRequest = IOUtils.toString(warehouseInsertRequestResource.getInputStream(), StandardCharsets.UTF_8);
        warehouseUpdateRequest = IOUtils.toString(warehouseUpdateRequestResource.getInputStream(), StandardCharsets.UTF_8);
        warehouseLongFieldRequest = IOUtils.toString(warehouseLongFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
        warehouseNullFieldRequest = IOUtils.toString(warehouseNullFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
    }

    @Test
    public void warehouseRepositoryInsert() throws Exception {
        restTemplate.postForEntity("/balanceUnit", balanceUnitInsertRequest, Object.class);
        List<WarehouseDTO> warehouseInsertExpected = objectMapper.readValue(warehouseInsertRequest, new TypeReference<List<WarehouseDTO>>() {
        });
        ResponseEntity responseEntityInsert = restTemplate.postForEntity("/warehouse", warehouseInsertRequest, Object.class);
        assertEquals(HttpStatus.ACCEPTED, responseEntityInsert.getStatusCode());
        List<Warehouse> warehouses = warehouseRestRepository.findAll();
        assertFalse(warehouses.isEmpty());
        warehouseInsertExpected.sort(Comparator.comparing(WarehouseDTO::getMdmId));
        warehouses.sort(Comparator.comparing(Warehouse::getMdmId));
        for (int i = 0; i < warehouseInsertExpected.size(); i++) {
            Assertions.assertThat(warehouseInsertExpected.get(i)).isEqualToIgnoringGivenFields(warehouses.get(i), "LAST_MOD_DATE", "FIRST_ADD_DATE");
        }
    }

    @Test
    public void warehouseRepositoryUpdate() throws Exception {
        restTemplate.postForEntity("/balanceUnit", balanceUnitInsertRequest, Object.class);
        restTemplate.postForEntity("/warehouse", warehouseInsertRequest, Object.class);
        List<WarehouseDTO> warehouseUpdateExpected = objectMapper.readValue(warehouseUpdateRequest, new TypeReference<List<WarehouseDTO>>() {
        });
        ResponseEntity responseEntityUpdate = restTemplate.postForEntity("/warehouse", warehouseUpdateRequest, Object.class);
        assertEquals(HttpStatus.ACCEPTED, responseEntityUpdate.getStatusCode());
        List<Warehouse> warehouses = warehouseRestRepository.findAll();
        assertFalse(warehouses.isEmpty());
        warehouseUpdateExpected.sort(Comparator.comparing(WarehouseDTO::getMdmId));
        warehouses.sort(Comparator.comparing(Warehouse::getMdmId));
        for (int i = 0; i < warehouseUpdateExpected.size(); i++) {
            Assertions.assertThat(warehouseUpdateExpected.get(i)).isEqualToIgnoringGivenFields(warehouses.get(i), "LAST_MOD_DATE", "FIRST_ADD_DATE");
        }
    }

    @Test
    public void longFieldRequest() {
        restTemplate.postForEntity("/balanceUnit", balanceUnitInsertRequest, Object.class);
        ResponseEntity responseEntity = restTemplate.postForEntity("/warehouse", warehouseLongFieldRequest, Object.class);
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }

    @Test
    public void nullFieldRequest() {
        restTemplate.postForEntity("/balanceUnit", balanceUnitInsertRequest, Object.class);
        ResponseEntity responseEntity = restTemplate.postForEntity("/warehouse", warehouseNullFieldRequest, Object.class);
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }
}