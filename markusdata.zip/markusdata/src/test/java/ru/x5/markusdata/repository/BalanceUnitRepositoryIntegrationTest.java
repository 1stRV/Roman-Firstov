package ru.x5.markusdata.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.x5.markusdata.entity.dto.BalanceUnitDTO;
import ru.x5.markusdata.entity.jpa.BalanceUnit;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

public class BalanceUnitRepositoryIntegrationTest extends AbstractRepositoryTest {

    @Autowired
    private BalanceUnitRepository balanceUnitRestRepository;

    @Value("classpath:json/balance-unit.json")
    private Resource balanceUnitInsertRequestResource;

    @Value("classpath:json/balance-unit-change.json")
    private Resource balanceUnitUpdateRequestResource;

    @Value("classpath:json/balance-unit-long-field.json")
    private Resource balanceUnitLongFieldRequestResource;

    @Value("classpath:json/balance-unit-null-name-field.json")
    private Resource balanceUnitNullFieldRequestResource;

    private String balanceUnitInsertRequest;

    private String balanceUnitUpdateRequest;

    private String balanceUnitLongFieldRequest;

    private String balanceUnitNullFieldRequest;

    @Before
    public void init() throws IOException {
        balanceUnitInsertRequest = IOUtils.toString(balanceUnitInsertRequestResource.getInputStream(), StandardCharsets.UTF_8);
        balanceUnitUpdateRequest = IOUtils.toString(balanceUnitUpdateRequestResource.getInputStream(), StandardCharsets.UTF_8);
        balanceUnitLongFieldRequest = IOUtils.toString(balanceUnitLongFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
        balanceUnitNullFieldRequest = IOUtils.toString(balanceUnitNullFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
    }

    @Test
    public void balanceUnitRepositoryInsert() throws Exception {
        List<BalanceUnitDTO> balanceUnitInsertExpected = objectMapper.readValue(balanceUnitInsertRequest, new TypeReference<List<BalanceUnitDTO>>() {
        });
        ResponseEntity responseEntity = restTemplate.postForEntity("/balanceUnit", balanceUnitInsertRequest, Object.class);
        assertEquals(HttpStatus.ACCEPTED, responseEntity.getStatusCode());
        List<BalanceUnit> balanceUnits = balanceUnitRestRepository.findAll();
        assertFalse(balanceUnits.isEmpty());
        balanceUnitInsertExpected.sort(Comparator.comparing(BalanceUnitDTO::getMdmId));
        balanceUnits.sort(Comparator.comparing(BalanceUnit::getMdmId));
        for (int i = 0; i < balanceUnitInsertExpected.size(); i++) {
            Assertions.assertThat(balanceUnitInsertExpected.get(i)).isEqualToIgnoringGivenFields(balanceUnits.get(i), "LAST_MOD_DATE", "FIRST_ADD_DATE");
        }
    }

    @Test
    public void balanceUnitRepositoryUpdate() throws Exception {
        restTemplate.postForEntity("/balanceUnit", balanceUnitInsertRequest, Object.class);
        List<BalanceUnitDTO> balanceUnitUpdateExpected = objectMapper.readValue(balanceUnitUpdateRequest, new TypeReference<List<BalanceUnitDTO>>() {
        });
        ResponseEntity responseEntityUpdate = restTemplate.postForEntity("/balanceUnit", balanceUnitUpdateRequest, Object.class);
        assertEquals(HttpStatus.ACCEPTED, responseEntityUpdate.getStatusCode());
        List<BalanceUnit> balanceUnits = balanceUnitRestRepository.findAll();
        assertFalse(balanceUnits.isEmpty());
        balanceUnitUpdateExpected.sort(Comparator.comparing(BalanceUnitDTO::getMdmId));
        balanceUnits.sort(Comparator.comparing(BalanceUnit::getMdmId));
        for (int i = 0; i < balanceUnitUpdateExpected.size(); i++) {
            Assertions.assertThat(balanceUnitUpdateExpected.get(i)).isEqualToIgnoringGivenFields(balanceUnits.get(i), "LAST_MOD_DATE", "FIRST_ADD_DATE");
        }
    }

    @Test
    public void longFieldRequest() {
        ResponseEntity responseEntity = restTemplate.postForEntity("/balanceUnit", balanceUnitLongFieldRequest, Object.class);
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }

    @Test
    public void nullFieldRequest() {
        ResponseEntity responseEntity = restTemplate.postForEntity("/balanceUnit", balanceUnitNullFieldRequest, Object.class);
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }
}