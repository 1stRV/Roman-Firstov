package ru.x5.markusdata.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.x5.markusdata.entity.dto.GtinsDTO;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.jpa.Gtins;
import ru.x5.markusdata.entity.jpa.Item;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

public class ItemRepositoryIntegrationTest extends AbstractRepositoryTest {
    @Autowired
    private ItemRepository itemRestRepository;

    @Value("classpath:json/item.json")
    private Resource itemInsertRequestResource;

    @Value("classpath:json/item-change.json")
    private Resource itemUpdateRequestResource;

    @Value("classpath:json/item-long-field.json")
    private Resource itemLongFieldRequestResource;

    @Value("classpath:json/item-package-id-null-field.json")
    private Resource itemNullFieldRequestResource;

    private String itemInsertRequest;

    private String itemUpdateRequest;

    private String itemLongFieldRequest;

    private String itemNullFieldRequest;

    @Before
    public void init() throws IOException {
        itemInsertRequest = IOUtils.toString(itemInsertRequestResource.getInputStream(), StandardCharsets.UTF_8);
        itemUpdateRequest = IOUtils.toString(itemUpdateRequestResource.getInputStream(), StandardCharsets.UTF_8);
        itemLongFieldRequest = IOUtils.toString(itemLongFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
        itemNullFieldRequest = IOUtils.toString(itemNullFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
    }

    @Test
    public void itemRepositoryInsert() throws Exception {
        List<ItemDTO> itemInsertExpected = objectMapper.readValue(itemInsertRequest, new TypeReference<List<ItemDTO>>() {
        });
        ResponseEntity responseEntity = restTemplate.postForEntity("/item", itemInsertRequest, Object.class);
        assertEquals(HttpStatus.ACCEPTED, responseEntity.getStatusCode());
        List<Item> items = itemRestRepository.findAll();
        assertFalse(items.isEmpty());
        itemInsertExpected.sort(Comparator.comparing(ItemDTO::getPluId));
        items.sort(Comparator.comparing(Item::getPluId));
        for (int i = 0; i < itemInsertExpected.size(); i++) {
            List<GtinsDTO> gtinsDTO = itemInsertExpected.get(i).getGtins();
            List<Gtins> gtins = items.get(i).getGtins();
            gtinsDTO.sort(Comparator.comparing(GtinsDTO::getGtin));
            gtins.sort(Comparator.comparing(Gtins::getGtin));
            for (int j = 0; j < gtinsDTO.size(); j++) {
                Assertions.assertThat(gtinsDTO.get(j)).isEqualToIgnoringGivenFields(gtins.get(j), "tabaccoDateMrc");
            }
            Assertions.assertThat(itemInsertExpected.get(i)).isEqualToIgnoringGivenFields(items.get(i), "LAST_MOD_DATE", "FIRST_ADD_DATE", "gtins");
        }
    }

    @Test
    public void itemRepositoryUpdate() throws Exception {
        restTemplate.postForObject("/item", itemInsertRequest, Object.class);
        List<ItemDTO> itemUpdateExpected = objectMapper.readValue(itemUpdateRequest, new TypeReference<List<ItemDTO>>() {
        });
        restTemplate.postForObject("/item", itemUpdateRequest, Object.class);
        List<Item> items = itemRestRepository.findAll();
        assertFalse(items.isEmpty());
        itemUpdateExpected.sort(Comparator.comparing(ItemDTO::getPluId));
        items.sort(Comparator.comparing(Item::getPluId));
        for (int i = 0; i < itemUpdateExpected.size(); i++) {
            List<GtinsDTO> gtinsDTO = itemUpdateExpected.get(i).getGtins();
            List<Gtins> gtins = items.get(i).getGtins();
            gtinsDTO.sort(Comparator.comparing(GtinsDTO::getGtin));
            gtins.sort(Comparator.comparing(Gtins::getGtin));
            for (int j = 0; j < gtinsDTO.size(); j++) {
                Assertions.assertThat(gtinsDTO.get(j)).isEqualToIgnoringGivenFields(gtins.get(j), "tabaccoDateMrc");
            }
            Assertions.assertThat(itemUpdateExpected.get(i)).isEqualToIgnoringGivenFields(items.get(i), "LAST_MOD_DATE", "FIRST_ADD_DATE", "gtins");
        }
    }

    @Test
    public void longFieldRequest() {
        ResponseEntity responseEntity = restTemplate.postForEntity("/item", itemLongFieldRequest, Object.class);
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }

    @Test
    public void nullFieldRequest() {
        ResponseEntity responseEntity = restTemplate.postForEntity("/item", itemNullFieldRequest, Object.class);
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }
}