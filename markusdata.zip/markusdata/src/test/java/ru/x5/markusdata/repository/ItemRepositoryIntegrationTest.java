package ru.x5.markusdata.repository;

import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.x5.markusdata.entity.dto.GtinsDTO;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.jpa.Item;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ItemRepositoryIntegrationTest extends AbstractRepositoryTest {
    @Autowired
    private ItemRepository itemRestRepository;

    @Value("classpath:json/item.json")
    private Resource itemInsertRequestResource;

    @Value("classpath:json/item-change.json")
    private Resource itemUpdateRequestResource;

    @Value("classpath:json/item-long-field.json")
    private Resource itemLongFieldRequestResource;

    @Value("classpath:json/item-package-id-null-field.json")
    private Resource itemNullFieldRequestResource;

    private String itemInsertRequest;

    private String itemUpdateRequest;

    private String itemLongFieldRequest;

    private String itemNullFieldRequest;

    @Before
    public void init() throws IOException {
        itemInsertRequest = IOUtils.toString(itemInsertRequestResource.getInputStream(), StandardCharsets.UTF_8);
        itemUpdateRequest = IOUtils.toString(itemUpdateRequestResource.getInputStream(), StandardCharsets.UTF_8);
        itemLongFieldRequest = IOUtils.toString(itemLongFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
        itemNullFieldRequest = IOUtils.toString(itemNullFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
    }

    @Test
    public void itemRepositoryInsert() throws Exception {
        ItemDTO itemInsertExpected = objectMapper.readValue(itemInsertRequest, ItemDTO.class);
        ResponseEntity responseEntity = restTemplate.postForEntity("/item", itemInsertRequest, Object.class);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

        Optional<Item> optionalItem = itemRestRepository.findById(itemInsertExpected.getPluId());
        assertTrue(optionalItem.isPresent());
        Item itemFromDb = optionalItem.get();
        List<GtinsDTO> gtinsDTO = itemInsertExpected.getGtins();
        for (int i = 0; i < gtinsDTO.size(); i++) {
            Assertions.assertThat(gtinsDTO.get(i)).isEqualToIgnoringGivenFields(itemFromDb.getGtins().get(i), "tabaccoDateMrc");
        }
        Assertions.assertThat(itemInsertExpected).isEqualToIgnoringGivenFields(itemFromDb, "LAST_MOD_DATE", "FIRST_ADD_DATE", "gtins");
    }

    @Test
    public void itemRepositoryUpdate() throws Exception {
        restTemplate.postForObject("/item", itemInsertRequest, Object.class);

        ItemDTO itemUpdateExpected = objectMapper.readValue(itemUpdateRequest, ItemDTO.class);
        restTemplate.postForObject("/item", itemUpdateRequest, Object.class);

        Optional<Item> optionalItem = itemRestRepository.findById(itemUpdateExpected.getPluId());
        assertTrue(optionalItem.isPresent());
        Item itemFromDb = optionalItem.get();
        List<GtinsDTO> gtinsDTO = itemUpdateExpected.getGtins();
        for (int i = 0; i < gtinsDTO.size(); i++) {
            Assertions.assertThat(gtinsDTO.get(i)).isEqualToIgnoringGivenFields(itemFromDb.getGtins().get(i), "tabaccoDateMrc");
        }
        Assertions.assertThat(itemUpdateExpected).isEqualToIgnoringGivenFields(itemFromDb, "LAST_MOD_DATE", "FIRST_ADD_DATE", "gtins");
    }

    @Test
    public void longFieldRequest() {
        ResponseEntity responseEntity = restTemplate.postForEntity("/item", itemLongFieldRequest, Object.class);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }

    @Test
    public void nullFieldRequest() {
        ResponseEntity responseEntity = restTemplate.postForEntity("/item", itemNullFieldRequest, Object.class);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }
}