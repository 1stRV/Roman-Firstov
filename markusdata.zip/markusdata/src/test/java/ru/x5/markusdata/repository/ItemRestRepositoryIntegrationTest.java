package ru.x5.markusdata.repository;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import ru.x5.markusdata.entity.Item;

import java.io.IOException;
import java.net.URI;
import java.util.Optional;

public class ItemRestRepositoryIntegrationTest extends AbstractRestRepositoryTest {
    @Autowired
    private ItemRestRepository itemRestRepository;

    private static final String SERVICE_URI = "http://localhost:8088/item";

    @Value("classpath:json/item.json")
    private Resource itemInsertRequestResource;

    @Value("classpath:json/item-change.json")
    private Resource itemUpdateRequestResource;


    private String itemInsertRequest;

    private String itemUpdateRequest;

    @Before
    public void init() throws IOException {
        itemInsertRequest = IOUtils.toString(itemInsertRequestResource.getInputStream(), "UTF-8");
        itemUpdateRequest = IOUtils.toString(itemUpdateRequestResource.getInputStream(), "UTF-8");
    }

    @Test
    public void gtinsRepositoryInsertUpdateTest() throws Exception {
        Item itemInsertExpected = objectMapper.readValue(itemInsertRequest, Item.class);
        restTemplate.postForObject(new URI(SERVICE_URI), itemInsertRequest, Object.class);
        Item itemInsertActual = null;
        Optional<Item> optionalItem = itemRestRepository.findById(itemInsertExpected.getPluId());
        if (optionalItem.isPresent())
            itemInsertActual = optionalItem.get();
        Assert.assertEquals(itemInsertExpected, itemInsertActual);

        Item itemUpdateExpected = objectMapper.readValue(itemUpdateRequest, Item.class);
        restTemplate.postForObject(new URI(SERVICE_URI), itemUpdateRequest, Object.class);
        Item itemUpdateActual = null;
        optionalItem = itemRestRepository.findById(itemUpdateExpected.getPluId());
        if (optionalItem.isPresent())
            itemUpdateActual = optionalItem.get();
        Assert.assertEquals(itemUpdateExpected, itemUpdateActual);
    }
}