package ru.x5.markusdata.repository;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import ru.x5.markusdata.entity.BalanceUnit;

import java.io.IOException;
import java.net.URI;
import java.util.Optional;

public class BalanceUnitRestRepositoryIntegrationTest extends AbstractRestRepositoryTest {

    @Autowired
    private BalanceUnitRestRepository balanceUnitRestRepository;

    private static final String SERVICE_URI = "http://localhost:8088/balanceunit";

    @Value("classpath:json/balance-unit.json")
    private Resource balanceUnitInsertRequestResource;

    @Value("classpath:json/balance-unit-change.json")
    private Resource balanceUnitUpdateRequestResource;


    private String balanceUnitInsertRequest;

    private String balanceUnitUpdateRequest;

    @Before
    public void init() throws IOException {
        balanceUnitInsertRequest = IOUtils.toString(balanceUnitInsertRequestResource.getInputStream(), "UTF-8");
        balanceUnitUpdateRequest = IOUtils.toString(balanceUnitUpdateRequestResource.getInputStream(), "UTF-8");
    }

    @Test
    public void  balanceUnitRepositoryInsertUpdateTest() throws Exception {
        BalanceUnit balanceUnitInsertExpected = objectMapper.readValue(balanceUnitInsertRequest, BalanceUnit.class);
        restTemplate.postForObject(new URI(SERVICE_URI), balanceUnitInsertRequest, Object.class);
        BalanceUnit balanceUnitInsertActual = null;
        Optional<BalanceUnit> optionalBalanceUnit = balanceUnitRestRepository.findById(balanceUnitInsertExpected.getMdmId());
        if (optionalBalanceUnit.isPresent())
            balanceUnitInsertActual = optionalBalanceUnit.get();
        Assert.assertEquals(balanceUnitInsertExpected, balanceUnitInsertActual);

        BalanceUnit balanceUnitUpdateExpected = objectMapper.readValue(balanceUnitUpdateRequest, BalanceUnit.class);
        restTemplate.postForObject(new URI(SERVICE_URI), balanceUnitUpdateRequest, Object.class);
        BalanceUnit balanceUnitUpdateActual = null;
        optionalBalanceUnit = balanceUnitRestRepository.findById(balanceUnitUpdateExpected.getMdmId());
        if (optionalBalanceUnit.isPresent())
            balanceUnitUpdateActual = optionalBalanceUnit.get();
        Assert.assertEquals(balanceUnitUpdateExpected, balanceUnitUpdateActual);
    }

    @Test
    public void incorrect() throws Exception {

    }
}

//ложим в базу данные, проверяем, что они там лежат,+
// потом делаем обновление, проверяем, что там лежит те самые данные, которые мы закинули новые и проверяем по тому же айдишнику+


// 1)add @OneToMany
//2) add в @OneToMany(optional=false продебажить)
//3) новый тест: проверить что если сохраняешь без обязательного поля, то сохранить нельзя.
//точно:
//List<WareHouse> относится к List<BalanceUnit> @ManyToMany