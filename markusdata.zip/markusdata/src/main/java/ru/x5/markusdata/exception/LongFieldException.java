package ru.x5.markusdata.exception;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class LongFieldException extends RuntimeException {
    public LongFieldException(String message) {
        super(message);
    }
}
