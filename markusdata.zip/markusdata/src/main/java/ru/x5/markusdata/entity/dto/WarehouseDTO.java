package ru.x5.markusdata.entity.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class WarehouseDTO implements Serializable {

    @JsonProperty(value = "MDM_ID")
    private String mdmId;

    @JsonProperty(value = "NAME")
    private String name;

    @JsonProperty(value = "BALANCE_UNIT")
    private String balanceUnit;

    @JsonProperty(value = "INN")
    private String inn;

    @JsonProperty(value = "KPP")
    private String kpp;

    @JsonProperty(value = "WERK_REGION_CODE")
    private String werkRegionCode;

    @JsonProperty(value = "WERK_REGION_NAME")
    private String werkRegionName;
}