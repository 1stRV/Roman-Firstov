package ru.x5.markusdata.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Data
public class Warehouse {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @NotNull
    private String mdmId;

    @NotNull
    @JsonProperty("NAME")
    private String name;

    @NotNull
    @ManyToMany(mappedBy = "balanceunit",fetch = FetchType.EAGER)
    @JsonProperty("BALANCE_UNIT")
    private List<BalanceUnit> balanceUnits;

    @NotNull
    @JsonProperty("INN")
    private String inn;

    @JsonProperty("KPP")
    private String kpp;

    @JsonProperty("IS_NO_TOBACCO")
    private String isNoTobacco;

    @NotNull
    @JsonProperty("LAST_MOD_DATE")
    private Timestamp lastModDate;

    @NotNull
    @JsonProperty("LAST_MOD_USER")
    private String lastModUser;

    @NotNull
    @JsonProperty("FIRST_ADD_DATE")
    private Timestamp firstAddDate;
}


