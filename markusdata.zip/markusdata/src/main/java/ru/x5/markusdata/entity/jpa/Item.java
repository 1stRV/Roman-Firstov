package ru.x5.markusdata.entity.jpa;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
@Entity
@Table(name = "ITEMS")
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@Builder
@NoArgsConstructor
@Setter
@Getter
public class Item {

    @Id
    @JsonProperty(value = "PLU_ID")
    @Column(name = "PLU_ID", nullable = false, length = 18)
    private String pluId;

    @JsonProperty(value = "FULLNAME")
    @Column(name = "FULLNAME", nullable = false, length = 132)
    private String fullname;

    @JsonProperty(value = "UNITS_IN_PACKAGING")
    @Column(name = "UNITS_IN_PACKAGING", length = 3)
    private Integer unitsInPackaging;

    @JsonProperty(value = "PACKAGE_ID")
    @Column(name = "PACKAGE_ID", nullable = false, length = 20)
    private String packageId;

    @JsonProperty(value = "PACKAGE_CH_ID")
    @Column(name = "PACKAGE_CH_ID", nullable = false, length = 20)
    private String packageChId;

    @JsonProperty(value = "PACKAGE_LEVEL")
    @Column(name = "PACKAGE_LEVEL", length = 40)
    private String packageLevel;

    @JsonProperty(value = "AMOUNT_IN_PACKAGING")
    @Column(name = "AMOUNT_IN_PACKAGING", length = 5)
    private Integer amountInPackaging;

    @JsonProperty(value = "LAST_MOD_DATE")
    @LastModifiedDate
    @Column(name = "LAST_MOD_DATE")
    private Timestamp lastModDate;

    @JsonProperty(value = "FIRST_ADD_DATE")
    @CreatedDate
    @Column(name = "FIRST_ADD_DATE")
    private Timestamp firstAddDate;

    @JsonProperty(value = "GTINS")
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "item", fetch = FetchType.EAGER)
    private List<Gtins> gtins = new ArrayList<>();
}