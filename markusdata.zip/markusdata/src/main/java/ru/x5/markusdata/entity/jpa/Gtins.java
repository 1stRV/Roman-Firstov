package ru.x5.markusdata.entity.jpa;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.ZonedDateTime;

@Entity
@Table(name = "GTINS")
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@Builder
@NoArgsConstructor
@ToString
@Getter
public class Gtins {

    @Id
    @JsonProperty(value = "GTIN")
    @Column(name = "GTIN", nullable = false, length = 18)
    private String gtin;

    @JsonProperty(value = "PLU_ID")
    @Column(name = "PLU_ID", length = 18, insertable = false, updatable = false)
    private String pluId;

    @JsonProperty(value = "BAR_CODE_TYPE")
    @Column(name = "BAR_CODE_TYPE")
    private String barCodeType;

    @JsonProperty(value = "TABACCO_MRC")
    @Column(name = "TABACCO_MRC", length = 8)
    private BigDecimal tabaccoMrc;

    @JsonProperty(value = "TABACCO_DATE_MRC")
    @Column(name = "TABACCO_DATE_MRC")
    private ZonedDateTime tabaccoDateMrc;

    @JsonProperty(value = "LAST_MOD_DATE")
    @LastModifiedDate
    @Column(name = "LAST_MOD_DATE")
    private Timestamp lastModDate;

    @JsonProperty(value = "FIRST_ADD_DATE")
    @CreatedDate
    @Column(name = "FIRST_ADD_DATE")
    private Timestamp firstAddDate;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ID_ITEM")
    @JsonIgnore
    private Item item;
}