package ru.x5.markusdata.service;

import ru.x5.markusdata.entity.dto.BalanceUnitDTO;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.dto.WarehouseDTO;
import ru.x5.markusdata.entity.jpa.BalanceUnit;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.entity.jpa.Warehouse;

public interface MarkusDataService {

    Item saveItem(ItemDTO itemDTO);

    BalanceUnit saveBalanceUnit(BalanceUnitDTO balanceUnitDTO);

    Warehouse saveWarehouse(WarehouseDTO warehouseDTO);
}