package ru.x5.markusdata.controller.hadler;

import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.exception.DataException;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.naming.ServiceUnavailableException;

@ControllerAdvice
public class AdviceController {

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity handleConstraintViolation(ConstraintViolationException ex) {
        return ResponseEntity.status(400).body(ex.getLocalizedMessage());
    }

    @ExceptionHandler(DataException.class)
    public ResponseEntity handleDataException(DataException ex) {
        return ResponseEntity.status(400).contentType(MediaType.APPLICATION_JSON).body(ex.getLocalizedMessage());
    }

    @ExceptionHandler(ServiceUnavailableException.class)
    public ResponseEntity handleServiceUnavailable(ServiceUnavailableException ex) {
        return ResponseEntity.status(503).body(ex.getLocalizedMessage());
    }
}