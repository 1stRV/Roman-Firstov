package ru.x5.markusdata.controller.hadler;

import lombok.extern.log4j.Log4j2;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.exception.DataException;
import org.hibernate.exception.GenericJDBCException;
import org.hibernate.id.IdentifierGenerationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import ru.x5.markusdata.exception.NullFieldException;

import javax.naming.ServiceUnavailableException;

@ControllerAdvice
@Log4j2
public class AdviceController {
    private static final String MAX_LENGHT = "Превышена максимально допустимая длина поля:";
    private static final String MARKUS_UNAVAILABLE = "Маркус не доступен:";
    private static final String NOT_FOUND_ID = "Отсутствует id у сущности:";
    private static final String NULL_FIELD = "Обязательное поле пустое:";

    @ExceptionHandler(GenericJDBCException.class)
    public ResponseEntity handleJDBCException(GenericJDBCException ex) {
        log.error(MAX_LENGHT, ex);
        return new ResponseEntity(HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(DataException.class)
    public ResponseEntity handleDataException(DataException ex) {
        log.error(MAX_LENGHT, ex);
        return new ResponseEntity(HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ServiceUnavailableException.class)
    public ResponseEntity handleServiceUnavailable(ServiceUnavailableException ex) {
        log.error(MARKUS_UNAVAILABLE, ex);
        return new ResponseEntity(HttpStatus.SERVICE_UNAVAILABLE);
    }

    @ExceptionHandler(IdentifierGenerationException.class)
    public ResponseEntity handleIdentifier(IdentifierGenerationException ex) {
        log.error(NOT_FOUND_ID, ex);
        return new ResponseEntity(HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity handleConstraintViolation(ConstraintViolationException ex) {
        log.error(NULL_FIELD, ex);
        return new ResponseEntity(HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(NullFieldException.class)
    public ResponseEntity handleConstraintViolation(NullFieldException ex) {
        log.error(NULL_FIELD, ex);
        return new ResponseEntity(HttpStatus.BAD_REQUEST);
    }
}