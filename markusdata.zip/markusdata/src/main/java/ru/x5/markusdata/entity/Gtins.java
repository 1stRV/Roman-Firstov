
package ru.x5.markusdata.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.sql.Timestamp;

@Entity
@Data
public class Gtins {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @NotNull
    private String gtin;

    @JsonProperty("IS_MAIN")
    private String isMain;

    @NotNull
    @JsonProperty("PLU_ID")
    private String pluId;

    @JsonProperty("BAR_CODE_TYPE")
    private String barCodeType;

    @JsonProperty("IS_TABACCO")
    private String isTabacco;

    @JsonProperty("TABACCO_MRC")
    private String tabaccoMrc;

    @JsonProperty("TABACCO_DATE_MRC")
    private String tabaccoDateMrc;

    @NotNull
    @JsonProperty("LAST_MOD_DATE")
    private Timestamp lastModDate;

    @NotNull
    @JsonProperty("LAST_MOD_USER")
    private String lastModUser;

    @NotNull
    @JsonProperty("FIRST_ADD_DATE")
    private Timestamp firstAddDate;
}