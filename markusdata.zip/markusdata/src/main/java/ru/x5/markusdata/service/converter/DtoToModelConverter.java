package ru.x5.markusdata.service.converter;

import org.hibernate.exception.DataException;
import ru.x5.markusdata.entity.dto.BalanceUnitDTO;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.dto.WarehouseDTO;
import ru.x5.markusdata.entity.jpa.BalanceUnit;
import ru.x5.markusdata.entity.jpa.Gtins;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.entity.jpa.Warehouse;
import ru.x5.markusdata.exception.NullFieldException;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DtoToModelConverter {
    private static final String MAX_LENGHT = "Превышена максимально допустимая длина поля:";
    private static final String MARKUS_UNAVAILABLE = "Маркус не доступен:";
    private static final String NOT_FOUND_ID = "Отсутствует id у сущности:";
    private static final String NULL_FIELD = "Обязательное поле пустое:";

    private DtoToModelConverter() {
    }

    public static List<BalanceUnit> balanceUnitDtoList2modelList(List<BalanceUnitDTO> balanceUnitsDTO) {
//        return balanceUnitsDTO
//                .stream()
//                .map(balanceUnitDTO -> BalanceUnit.builder()
//                        .mdmId(balanceUnitDTO.getMdmId())
//                        .inn(balanceUnitDTO.getInn())
//                        .name(balanceUnitDTO.getName())
//                        .build()).collect(Collectors.toList());

        List<BalanceUnit> balanceUnits = new ArrayList<>();
        for (BalanceUnitDTO balanceUnit : balanceUnitsDTO) {
            String name = balanceUnit.getName();

            if (name == null) {
                balanceUnitsDTO
                        .stream()
                        .map(balanceUnitDTO -> BalanceUnit.builder()
                                .mdmId(balanceUnitDTO.getMdmId())
                                .inn(balanceUnitDTO.getInn())
                                .name(balanceUnitDTO.getName())
                                .build()).collect(Collectors.toList());
                throw new NullFieldException();
            }else {
                balanceUnitsDTO
                .stream()
                .map(balanceUnitDTO -> BalanceUnit.builder()
                        .mdmId(balanceUnitDTO.getMdmId())
                        .inn(balanceUnitDTO.getInn())
                        .name(balanceUnitDTO.getName())
                        .build()).collect(Collectors.toList());
            }
//            if (name == null) {
//                balanceUnit.setName(null);
//                throw new RuntimeException();
//            } else {
//                balanceUnit.setName(name);
//            }
//
//            String inn = balanceUnit.getInn();
//            if (inn == null) {
//                balanceUnit.setInn(null);
//            } else {
//                balanceUnit.setInn(inn);
//            }


        }


//        List<BalanceUnit> list;
//        try {
//            list = balanceUnitsDTO
//                    .stream()
//                    .map(balanceUnitDTO -> BalanceUnit.builder()
//                            .mdmId(balanceUnitDTO.getMdmId())
//                            .inn(balanceUnitDTO.getInn())
//                            .name(balanceUnitDTO.getName())
//                            .build()).collect(Collectors.toList());
//        } catch (DataException ex) {
//            list = balanceUnitsDTO
//                    .stream()
//                    .map(balanceUnitDTO -> BalanceUnit.builder()
//                            .mdmId(balanceUnitDTO.getMdmId())
//                            .inn(null)
//                            .name(balanceUnitDTO.getName())
//                            .build()).collect(Collectors.toList());
//        }
//        return list;
    }

    public static List<Item> itemDtoList2modelList(List<ItemDTO> itemsDTO) {
        List<Item> items = new ArrayList<>();
        for (ItemDTO itemDTO : itemsDTO) {
            Item item = Item.builder()
                    .pluId(itemDTO.getPluId())
                    .fullname(itemDTO.getFullname())
                    .unitsInPackaging(itemDTO.getUnitsInPackaging())
                    .packageId(itemDTO.getPackageId())
                    .packageChId(itemDTO.getPackageChId())
                    .packageLevel(itemDTO.getPackageLevel())
                    .amountInPackaging(itemDTO.getAmountInPackaging())
                    .build();
            item.setGtins(itemDTO.getGtins()
                    .stream()
                    .map(gtinsDTO -> Gtins.builder()
                            .gtin(gtinsDTO.getGtin())
                            .pluId(gtinsDTO.getPluId())
                            .barCodeType(gtinsDTO.getBarCodeType())
                            .tabaccoMrc(gtinsDTO.getTabaccoMrc())
                            .tabaccoDateMrc(gtinsDTO.getTabaccoDateMrc())
                            .item(item)
                            .build())
                    .collect(Collectors.toList()));
            items.add(item);
        }
        return items;
    }

    public static List<Warehouse> warehouseDtoList2modelList(List<WarehouseDTO> warehousesDTO) {
        return warehousesDTO
                .stream()
                .map(warehouseDTO -> Warehouse.builder()
                        .mdmId(warehouseDTO.getMdmId())
                        .name(warehouseDTO.getName())
                        .balanceUnit(warehouseDTO.getBalanceUnit())
                        .inn(warehouseDTO.getInn())
                        .kpp(warehouseDTO.getKpp())
                        .werkRegionCode(warehouseDTO.getWerkRegionCode())
                        .werkRegionName(warehouseDTO.getWerkRegionName())
                        .build()).collect(Collectors.toList());
    }
}