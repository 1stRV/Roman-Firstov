package ru.x5.markusdata.service.converter;

import ru.x5.markusdata.entity.dto.BalanceUnitDTO;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.dto.WarehouseDTO;
import ru.x5.markusdata.entity.jpa.BalanceUnit;
import ru.x5.markusdata.entity.jpa.Gtins;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.entity.jpa.Warehouse;

import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import java.util.stream.Collectors;

public class DtoToModelConverter {
    private DtoToModelConverter() {
    }

    public static List<BalanceUnit> balanceUnitDtoList2modelList(List<BalanceUnitDTO> balanceUnitsDTO) {
        return balanceUnitsDTO
                .stream()
                .map(balanceUnitDTO -> BalanceUnit.builder()
                        .mdmId(balanceUnitDTO.getMdmId())
                        .inn(balanceUnitDTO.getInn())
                        .name(balanceUnitDTO.getName())
                        .build()).collect(Collectors.toList());
    }

    public static List<Item> itemDtoList2modelList(List<ItemDTO> itemsDTO) {
        List<Item> items = new ArrayList<>();
        for (ItemDTO itemDTO : itemsDTO) {
            Item item = Item.builder()
                    .pluId(itemDTO.getPluId())
                    .fullname(itemDTO.getFullname())
                    .unitsInPackaging(itemDTO.getUnitsInPackaging())
                    .packageId(itemDTO.getPackageId())
                    .packageChId(itemDTO.getPackageChId())
                    .packageLevel(itemDTO.getPackageLevel())
                    .amountInPackaging(itemDTO.getAmountInPackaging())
                    .build();
            item.setGtins(itemDTO.getGtins()
                    .stream()
                    .map(gtinsDTO -> Gtins.builder()
                            .gtin(gtinsDTO.getGtin())
                            .pluId(gtinsDTO.getPluId())
                            .barCodeType(gtinsDTO.getBarCodeType())
                            .tabaccoMrc(gtinsDTO.getTabaccoMrc())
                            .tabaccoDateMrc(gtinsDTO.getTabaccoDateMrc())
                            .item(item)
                            .isTabacco(gtinsDTO.getIsTabacco())
                            .isMain(gtinsDTO.getIsMain())
                            .build())
                    .collect(Collectors.toList()));
            items.add(item);
        }
        return items;
    }

    public static List<Warehouse> warehouseDtoList2modelList(List<WarehouseDTO> warehousesDTO) {
//        return warehousesDTO
//                .stream()
//                .map(warehouseDTO -> Warehouse.builder()
//                        .mdmId(warehouseDTO.getMdmId())
//                        .name(warehouseDTO.getName())
//                        .balanceUnit(warehouseDTO.getBalanceUnit())
//                        .inn(warehouseDTO.getInn())
//                        .kpp(warehouseDTO.getKpp())
//                        .werkRegionCode(warehouseDTO.getWerkRegionCode())
//                        .werkRegionName(warehouseDTO.getWerkRegionName())
//                        .isNoTobacco(warehouseDTO.getIsNoTobacco())
//                        .salesChannel(warehouseDTO.getSalesChannel())
//                        .build()).collect(Collectors.toList());

//        ZoneId zone = ZoneId.of();
//        ZonedDateTime zdt = dt.atZone(zone);
//        ZoneOffset offset = zdt.getOffset();


        List<Warehouse> warehouses = new ArrayList<>();

        Warehouse warehouse = new Warehouse();


        for (ItemDTO itemDTO : itemsDTO) {

        }



    }
}