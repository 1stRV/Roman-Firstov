package ru.x5.markusdata.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.x5.markusdata.entity.dto.BalanceUnitDTO;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.dto.WarehouseDTO;
import ru.x5.markusdata.entity.jpa.BalanceUnit;
import ru.x5.markusdata.entity.jpa.Gtins;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.entity.jpa.Warehouse;
import ru.x5.markusdata.repository.BalanceUnitRepository;
import ru.x5.markusdata.repository.ItemRepository;
import ru.x5.markusdata.repository.WarehouseRepository;
import ru.x5.markusdata.service.MarkusDataService;

import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MarkusDataServiceImpl implements MarkusDataService {

    private final BalanceUnitRepository balanceUnitRepository;
    private final ItemRepository itemRepository;
    private final WarehouseRepository warehouseRepository;

    @Override
    public BalanceUnit saveBalanceUnit(BalanceUnitDTO balanceUnitDTO) {
        return balanceUnitRepository.save(BalanceUnit.builder()
                .mdmId(balanceUnitDTO.getMdmId())
                .inn(balanceUnitDTO.getInn())
                .name(balanceUnitDTO.getName())
                .build());
    }

    @Override
    public Item saveItem(ItemDTO itemDTO) {
        Item item = Item.builder()
                .pluId(itemDTO.getPluId())
                .fullname(itemDTO.getFullname())
                .unitsInPackaging(itemDTO.getUnitsInPackaging())
                .packageId(itemDTO.getPackageId())
                .packageChId(itemDTO.getPackageChId())
                .packageLevel(itemDTO.getPackageLevel())
                .amountInPackaging(itemDTO.getAmountInPackaging())
                .build();

        item.setGtins(itemDTO.getGtins()
                .stream()
                .map(gtinsDTO -> Gtins.builder()
                        .gtin(gtinsDTO.getGtin())
                        .pluId(gtinsDTO.getPluId())
                        .barCodeType(gtinsDTO.getBarCodeType())
                        .tabaccoMrc(gtinsDTO.getTabaccoMrc())
                        .tabaccoDateMrc(gtinsDTO.getTabaccoDateMrc())
                        .item(item)
                        .build())
                .collect(Collectors.toList()));
        return itemRepository.save(item);
    }

    @Override
    public Warehouse saveWarehouse(WarehouseDTO warehouseDTO) {
        return warehouseRepository.save(Warehouse.builder()
                .mdmId(warehouseDTO.getMdmId())
                .name(warehouseDTO.getName())
                .balanceUnit(warehouseDTO.getBalanceUnit())
                .inn(warehouseDTO.getInn())
                .kpp(warehouseDTO.getKpp())
                .werkRegionCode(warehouseDTO.getWerkRegionCode())
                .werkRegionName(warehouseDTO.getWerkRegionName())
                .build());
    }
}