package ru.x5.markusdata.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import ru.x5.markusdata.entity.dto.BalanceUnitDTO;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.dto.WarehouseDTO;
import ru.x5.markusdata.entity.jpa.BalanceUnit;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.entity.jpa.Warehouse;
import ru.x5.markusdata.repository.BalanceUnitRepository;
import ru.x5.markusdata.repository.ItemRepository;
import ru.x5.markusdata.repository.WarehouseRepository;
import ru.x5.markusdata.service.MarkusDataService;
import ru.x5.markusdata.service.converter.DtoToModelConverter;

import java.util.List;

@Log4j2
@Service
@RequiredArgsConstructor
public class MarkusDataServiceImpl implements MarkusDataService {
    private final BalanceUnitRepository balanceUnitRepository;
    private final ItemRepository itemRepository;
    private final WarehouseRepository warehouseRepository;
    private static final String SAVE_BALANCE_UNIT = "список BalanceUnit сохранен в БД";
    private static final String SAVE_ITEM = "список Item сохранен в БД";
    private static final String SAVE_WAREHOUSE = "список Warehouse сохранен в БД";

    @Override
    public List<BalanceUnit> saveBalanceUnits(List<BalanceUnitDTO> balanceUnitsDTO) {
        List<BalanceUnit> balanceUnitList = balanceUnitRepository.saveAll(DtoToModelConverter.balanceUnitDtoList2modelList(balanceUnitsDTO));
        log.info(SAVE_BALANCE_UNIT);
        return balanceUnitList;
    }

    @Override
    public List<Item> saveItems(List<ItemDTO> itemsDTO) {
        List<Item> itemList = itemRepository.saveAll(DtoToModelConverter.itemDtoList2modelList(itemsDTO));
        log.info(SAVE_ITEM);
        return itemList;
    }

    @Override
    public List<Warehouse> saveWarehouses(List<WarehouseDTO> warehousesDTO) {
        List<Warehouse> warehouseList = warehouseRepository.saveAll(DtoToModelConverter.warehouseDtoList2modelList(warehousesDTO));
        log.info(SAVE_WAREHOUSE);
        return warehouseList;
    }
}