package ru.x5.markusdata.entity.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.ZonedDateTime;

@Data
public class GtinsDTO implements Serializable {

    @JsonProperty(value = "GTIN")
    private String gtin;

    @JsonProperty(value = "PLU_ID")
    private String pluId;

    @JsonProperty(value = "BAR_CODE_TYPE")
    private String barCodeType;

    @JsonProperty(value = "TABACCO_MRC")
    private BigDecimal tabaccoMrc;

    @JsonProperty(value = "TABACCO_DATE_MRC")
    private ZonedDateTime tabaccoDateMrc;
}