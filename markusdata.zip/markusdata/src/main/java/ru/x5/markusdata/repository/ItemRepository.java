package ru.x5.markusdata.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path = "item")
public interface ItemRepository extends JpaRepository<GtinsRepository, Long> {
}
