package ru.x5.markusdata.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.lang.Nullable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;

@Entity
@Data
public class BalanceUnit {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
//    @NotNull
    @Nullable
    private String mdmId;

//    @NotNull
    @Nullable
    @JsonProperty("NAME")
    private String name;

//    @NotNull
    @Nullable
    @JsonProperty("INN")
    private String inn;

//    @NotNull
    @Nullable
    @JsonProperty("LAST_MOD_DATE")
    private Timestamp lastModDate;

//    @NotNull
    @Nullable
    @JsonProperty("LAST_MOD_USER")
    private String lastModUser;

//    @NotNull
    @Nullable
    @JsonProperty("FIRST_ADD_DATE")
    private Timestamp firstAddDate;
}