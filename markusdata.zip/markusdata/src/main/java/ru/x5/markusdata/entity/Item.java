package ru.x5.markusdata.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sun.xml.internal.bind.v2.model.core.ID;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;
import java.util.UUID;

@Entity
@Data
public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @NotNull
    private String pluId;

    @NotNull
    @JsonProperty("FULLNAME")
    private String fullname;

    @JsonProperty("UNITS_IN_PACKAGING")
    private String unitsInPackaging;

    @NotNull
    @JsonProperty("PACKAGE_ID")
    private String packageId;

    @NotNull
    @JsonProperty("PACKAGE_CH_ID")
    private String packageChId;

    @JsonProperty("PACKAGE_LEVEL")
    private String packageLevel;

    @JsonProperty("AMOUNT_IN_PACKAGING")
    private String amountInPackaging;

    @NotNull
    @JsonProperty("LAST_MOD_DATE")
    private Timestamp lastModDate;

    @NotNull
    @JsonProperty("LAST_MOD_USER")
    private String lastModUser;

    @NotNull
    @JsonProperty("FIRST_ADD_DATE")
    private Timestamp firstAddDate;
}