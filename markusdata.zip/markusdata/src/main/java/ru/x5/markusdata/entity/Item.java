package ru.x5.markusdata.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class Item {
    @Id
    @JsonProperty("PLU_ID")
    private String pluId;

    @JsonProperty("FULLNAME")
    private String fullname;

    @JsonProperty("UNITS_IN_PACKAGING")
    private String unitsInPackaging;

    @JsonProperty("PACKAGE_ID")
    private String packageId;

    @JsonProperty("PACKAGE_CH_ID")
    private String packageChId;

    @JsonProperty("PACKAGE_LEVEL")
    private String packageLevel;

    @JsonProperty("AMOUNT_IN_PACKAGING")
    private String amountInPackaging;

    @JsonProperty("LAST_MOD_DATE")
    private String lastModDate;

    @JsonProperty("LAST_MOD_USER")
    private String lastModUser;

    @JsonProperty("FIRST_ADD_DATE")
    private String firstAddDate;
}
