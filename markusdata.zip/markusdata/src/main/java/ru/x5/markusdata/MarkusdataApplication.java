package ru.x5.markusdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class MarkusdataApplication {

    public static void main(String[] args) {
        SpringApplication.run(MarkusdataApplication.class, args);
    }
}