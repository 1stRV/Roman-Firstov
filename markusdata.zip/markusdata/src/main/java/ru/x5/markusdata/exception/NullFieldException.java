package ru.x5.markusdata.exception;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class NullFieldException extends RuntimeException {
    public NullFieldException(String message) {
        super(message);
    }
}
