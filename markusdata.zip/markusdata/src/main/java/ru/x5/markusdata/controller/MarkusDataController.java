package ru.x5.markusdata.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.x5.markusdata.entity.dto.BalanceUnitDTO;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.dto.WarehouseDTO;
import ru.x5.markusdata.entity.jpa.BalanceUnit;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.entity.jpa.Warehouse;
import ru.x5.markusdata.service.MarkusDataService;

@RestController
@RequiredArgsConstructor
public class MarkusDataController {

    private final MarkusDataService markusDataService;

    @PostMapping(value = "/balanceUnit")
    public BalanceUnit saveBalanceUnit(@RequestBody BalanceUnitDTO balanceUnitDTO) {
        return markusDataService.saveBalanceUnit(balanceUnitDTO);
    }

    @PostMapping(value = "/item")
    public Item saveItem(@RequestBody ItemDTO itemDTO) {
        return markusDataService.saveItem(itemDTO);
    }

    @PostMapping(value = "/warehouse")
    public Warehouse saveWarehouse(@RequestBody WarehouseDTO warehouseDTO) {
        return markusDataService.saveWarehouse(warehouseDTO);
    }
}