package ru.x5.markusdata.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.x5.markusdata.entity.dto.BalanceUnitDTO;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.dto.WarehouseDTO;
import ru.x5.markusdata.service.MarkusDataService;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class MarkusDataController {

    private final MarkusDataService markusDataService;

    @PostMapping(value = "/balanceUnit")
    public ResponseEntity saveBalanceUnits(@RequestBody List<BalanceUnitDTO> balanceUnitsDTO) {
        markusDataService.saveBalanceUnits(balanceUnitsDTO);
        return new ResponseEntity(HttpStatus.ACCEPTED);
    }

    @PostMapping(value = "/item")
    public ResponseEntity saveItems(@RequestBody List<ItemDTO> itemDTO) {
        markusDataService.saveItems(itemDTO);
        return new ResponseEntity(HttpStatus.ACCEPTED);
    }

    @PostMapping(value = "/warehouse")
    public ResponseEntity saveWarehouses(@RequestBody List<WarehouseDTO> warehousesDTO) {
        markusDataService.saveWarehouses(warehousesDTO);
        return new ResponseEntity(HttpStatus.ACCEPTED);
    }
}