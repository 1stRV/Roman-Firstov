package ru.x5.markusdata.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.x5.markusdata.entity.dto.BalanceUnitDTO;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.dto.WarehouseDTO;
import ru.x5.markusdata.entity.jpa.BalanceUnit;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.entity.jpa.Warehouse;
import ru.x5.markusdata.service.MarkusDataService;

@RestController
@RequiredArgsConstructor
public class MarkusDataController {

    private final MarkusDataService markusDataService;

    @PostMapping(value = "/balanceUnit", produces = "application/json; charset=utf-8")
    public ResponseEntity saveBalanceUnit(@RequestBody BalanceUnitDTO balanceUnitDTO) {
        BalanceUnit balanceUnit = markusDataService.saveBalanceUnit(balanceUnitDTO);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(balanceUnit);
    }

    @PostMapping(value = "/item")
    public ResponseEntity saveItem(@RequestBody ItemDTO itemDTO) {
        Item item = markusDataService.saveItem(itemDTO);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(item);
    }

    @PostMapping(value = "/warehouse")
    public ResponseEntity saveWarehouse(@RequestBody WarehouseDTO warehouseDTO) {
        Warehouse warehouse = markusDataService.saveWarehouse(warehouseDTO);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(warehouse);
    }
}