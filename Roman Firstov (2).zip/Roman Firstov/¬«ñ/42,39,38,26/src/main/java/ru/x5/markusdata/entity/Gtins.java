
package ru.x5.markusdata.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
public class Gtins {

    @Id
    @JsonProperty("GTIN")
    private String gtin;

    @JsonProperty("IS_MAIN")
    private String isMain;

    @Column(nullable = false)
    @JsonProperty("PLU_ID")
    private String pluId;

    @JsonProperty("BAR_CODE_TYPE")
    private String barCodeType;

    @JsonProperty("IS_TABACCO")
    private String isTabacco;

    @JsonProperty("TABACCO_MRC")
    private String tabaccoMrc;

    @JsonProperty("TABACCO_DATE_MRC")
    private String tabaccoDateMrc;

    @Column(nullable = false)
    @JsonProperty("LAST_MOD_DATE")
    private Timestamp lastModDate;

    @Column(nullable = false)
    @JsonProperty("LAST_MOD_USER")
    private String lastModUser;

    @Column(nullable = false)
    @JsonProperty("FIRST_ADD_DATE")
    private Timestamp firstAddDate;
}