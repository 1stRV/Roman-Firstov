package ru.x5.markusdata.repository;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.x5.markusdata.entity.BalanceUnit;

import java.io.IOException;
import java.net.URI;
import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class BalanceUnitRestRepositoryIntegrationTest extends AbstractRestRepositoryTest {

    @Autowired
    private BalanceUnitRestRepository balanceUnitRestRepository;

    private static final String SERVICE_URI = "http://localhost:8088/balanceunit";

    @Value("classpath:json/balance-unit.json")
    private Resource balanceUnitInsertRequestResource;

    @Value("classpath:json/balance-unit-change.json")
    private Resource balanceUnitUpdateRequestResource;

    @Value("classpath:json/balance-unit-long-field.json")
    private Resource balanceUnitLongFieldRequestResource;

    @Value("classpath:json/balance-unit-null-field.json")
    private Resource balanceUnitNullFieldRequestResource;

    private String balanceUnitInsertRequest;

    private String balanceUnitUpdateRequest;

    private String balanceUnitLongFieldRequest;

    private String balanceUnitNullFieldRequest;

    @Before
    public void init() throws IOException {
        balanceUnitInsertRequest = IOUtils.toString(balanceUnitInsertRequestResource.getInputStream(), "UTF-8");
        balanceUnitUpdateRequest = IOUtils.toString(balanceUnitUpdateRequestResource.getInputStream(), "UTF-8");
        balanceUnitLongFieldRequest = IOUtils.toString(balanceUnitLongFieldRequestResource.getInputStream(), "UTF-8");
        balanceUnitNullFieldRequest = IOUtils.toString(balanceUnitNullFieldRequestResource.getInputStream(), "UTF-8");
    }

    @Test
    public void balanceUnitRepositoryInsertUpdateTest() throws Exception {
        BalanceUnit balanceUnitInsertExpected = objectMapper.readValue(balanceUnitInsertRequest, BalanceUnit.class);
        restTemplate.postForObject(new URI(SERVICE_URI), balanceUnitInsertRequest, Object.class);
        BalanceUnit balanceUnitInsertActual = null;
        Optional<BalanceUnit> optionalBalanceUnit = balanceUnitRestRepository.findById(balanceUnitInsertExpected.getMdmId());
        if (optionalBalanceUnit.isPresent())
            balanceUnitInsertActual = optionalBalanceUnit.get();
        assertEquals(balanceUnitInsertExpected, balanceUnitInsertActual);

        BalanceUnit balanceUnitUpdateExpected = objectMapper.readValue(balanceUnitUpdateRequest, BalanceUnit.class);
        restTemplate.postForObject(new URI(SERVICE_URI), balanceUnitUpdateRequest, Object.class);
        BalanceUnit balanceUnitUpdateActual = null;
        optionalBalanceUnit = balanceUnitRestRepository.findById(balanceUnitUpdateExpected.getMdmId());
        if (optionalBalanceUnit.isPresent())
            balanceUnitUpdateActual = optionalBalanceUnit.get();
        assertEquals(balanceUnitUpdateExpected, balanceUnitUpdateActual);
    }

    @Test
    public void longFieldRequest() throws Exception {
        ResponseEntity responseEntity = restTemplate.postForEntity(new URI(SERVICE_URI), (balanceUnitLongFieldRequest), Object.class);
        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());

    }

    @Test
    public void nullFieldRequest() throws Exception {
        ResponseEntity responseEntity = restTemplate.postForEntity(new URI(SERVICE_URI), (balanceUnitNullFieldRequest), Object.class);
        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());
    }
}