package ru.x5.markusdata.repository;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import ru.x5.markusdata.entity.Gtins;
import static org.junit.Assert.assertEquals;
import java.io.IOException;
import java.net.URI;
import java.util.Optional;
import org.springframework.http.HttpStatus;

public class GtinsRestRepositoryIntegrationTest extends AbstractRestRepositoryTest {
    @Autowired
    private GtinsRestRepository gtinsRestRepository;

    private static final String SERVICE_URI = "http://localhost:8088/gtins";

    @Value("classpath:json/g-tins.json")
    private Resource gtinsInsertRequestResource;

    @Value("classpath:json/g-tins-change.json")
    private Resource gtinsUpdateRequestResource;

    @Value("classpath:json/g-tins-long-field.json")
    private Resource gtinsLongFieldRequestResource;

    @Value("classpath:json/g-tins-null-field.json")
    private Resource gtinsNullFieldRequestResource;

    private String gtinsInsertRequest;

    private String gtinsUpdateRequest;

    private String gtinsLongFieldRequest;

    private String gtinsNullFieldRequest;

    @Before
    public void init() throws IOException {
        gtinsInsertRequest = IOUtils.toString(gtinsInsertRequestResource.getInputStream(), "UTF-8");
        gtinsUpdateRequest = IOUtils.toString(gtinsUpdateRequestResource.getInputStream(), "UTF-8");
        gtinsLongFieldRequest = IOUtils.toString(gtinsLongFieldRequestResource.getInputStream(), "UTF-8");
        gtinsNullFieldRequest = IOUtils.toString(gtinsNullFieldRequestResource.getInputStream(), "UTF-8");
    }
//restTemplate.postForObject(new URI(SERVICE_URI), balanceUnitInsertRequest, Object.class);
    @Test
    public void gtinsRepositoryInsertUpdateTest() throws Exception {
        Gtins gtinsInsertExpected = objectMapper.readValue(gtinsInsertRequest, Gtins.class);
        restTemplate.postForObject(new URI(SERVICE_URI), gtinsInsertRequest, Object.class);
        Gtins gtinsInsertActual = null;
        Optional<Gtins> optionalGtins = gtinsRestRepository.findById(gtinsInsertExpected.getGtin());
        if (optionalGtins.isPresent())
            gtinsInsertActual = optionalGtins.get();
        Assert.assertEquals(gtinsInsertExpected, gtinsInsertActual);

        Gtins gtinsUpdateExpected = objectMapper.readValue(gtinsUpdateRequest, Gtins.class);
        restTemplate.postForObject(new URI(SERVICE_URI), gtinsUpdateRequest, Object.class);
        Gtins gtinsUpdateActual = null;
        optionalGtins = gtinsRestRepository.findById(gtinsUpdateExpected.getGtin());
        if (optionalGtins.isPresent())
            gtinsUpdateActual = optionalGtins.get();
        Assert.assertEquals(gtinsUpdateExpected, gtinsUpdateActual);
    }

    @Test
    public void longFieldRequest() throws Exception {
        ResponseEntity responseEntity = restTemplate.postForEntity(new URI(SERVICE_URI), (gtinsLongFieldRequest), Object.class);
        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());

    }

    @Test
    public void nullFieldRequest() throws Exception {
        ResponseEntity responseEntity = restTemplate.postForEntity(new URI(SERVICE_URI), (gtinsNullFieldRequest), Object.class);
        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());
    }
}