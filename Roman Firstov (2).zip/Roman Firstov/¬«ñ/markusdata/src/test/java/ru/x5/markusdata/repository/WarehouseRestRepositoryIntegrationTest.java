package ru.x5.markusdata.repository;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.x5.markusdata.entity.Warehouse;

import java.io.IOException;
import java.net.URI;
import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class WarehouseRestRepositoryIntegrationTest extends AbstractRestRepositoryTest {
    @Autowired
    private WarehouseRestRepository warehouseRestRepository;

    private static final String SERVICE_URI = "http://localhost:8088/warehouse";

    @Value("classpath:json/warehouse.json")
    private Resource warehouseInsertRequestResource;

    @Value("classpath:json/warehouse-change.json")
    private Resource warehouseUpdateRequestResource;

    @Value("classpath:json/warehouse-long-field.json")
    private Resource warehouseLongFieldRequestResource;

    @Value("classpath:json/warehouse-null-field.json")
    private Resource warehouseNullFieldRequestResource;

    private String warehouseInsertRequest;

    private String warehouseUpdateRequest;

    private String warehouseLongFieldRequest;

    private String warehouseNullFieldRequest;

    @Before
    public void init() throws IOException {
        warehouseInsertRequest = IOUtils.toString(warehouseInsertRequestResource.getInputStream(), "UTF-8");
        warehouseUpdateRequest = IOUtils.toString(warehouseUpdateRequestResource.getInputStream(), "UTF-8");
        warehouseLongFieldRequest = IOUtils.toString(warehouseLongFieldRequestResource.getInputStream(), "UTF-8");
        warehouseNullFieldRequest = IOUtils.toString(warehouseNullFieldRequestResource.getInputStream(), "UTF-8");
    }

    @Test
    public void warehouseRepositoryInsertUpdateTest() throws Exception {
        Warehouse warehouseInsertExpected = objectMapper.readValue(warehouseInsertRequest, Warehouse.class);
        restTemplate.postForObject(new URI(SERVICE_URI), warehouseInsertRequest, Object.class);
        Warehouse warehouseInsertActual = null;
        Optional<Warehouse> optionalWarehouse = warehouseRestRepository.findById(warehouseInsertExpected.getMdmId());
        if (optionalWarehouse.isPresent())
            warehouseInsertActual = optionalWarehouse.get();
        Assert.assertEquals(warehouseInsertExpected, warehouseInsertActual);

        Warehouse warehouseUpdateExpected = objectMapper.readValue(warehouseUpdateRequest, Warehouse.class);
        restTemplate.postForObject(new URI(SERVICE_URI), warehouseUpdateRequest, Object.class);
        Warehouse warehouseUpdateActual = null;
        optionalWarehouse = warehouseRestRepository.findById(warehouseUpdateExpected.getMdmId());
        if (optionalWarehouse.isPresent())
            warehouseUpdateActual = optionalWarehouse.get();
        Assert.assertEquals(warehouseUpdateExpected, warehouseUpdateActual);
    }

    @Test
    public void longFieldRequest() throws Exception {
        ResponseEntity responseEntity = restTemplate.postForEntity(new URI(SERVICE_URI), (warehouseLongFieldRequest), Object.class);
        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());

    }

    @Test
    public void nullFieldRequest() throws Exception {
        ResponseEntity responseEntity = restTemplate.postForEntity(new URI(SERVICE_URI), (warehouseNullFieldRequest), Object.class);
        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());
    }
}