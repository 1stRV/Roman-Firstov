package ru.x5.markusdata.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
public class Warehouse {

//    @Id
//    private Long id;

    @JsonProperty("MDM_ID")
    private String mdmId;

    @JsonProperty("NAME")
    private String name;

    @JsonProperty("BALANCE_UNIT")
    private String unitsInPackaging;

    @JsonProperty("INN")
    private String inn;

    @JsonProperty("KPP")
    private String kpp;

    @JsonProperty("IS_NO_TOBACCO")
    private String isNoTobacco;

    @JsonProperty("LAST_MOD_DATE")
    private String lastModDate;

    @JsonProperty("LAST_MOD_USER")
    private String lastModUser;

    @JsonProperty("FIRST_ADD_DATE")
    private String firstAddDate;
}