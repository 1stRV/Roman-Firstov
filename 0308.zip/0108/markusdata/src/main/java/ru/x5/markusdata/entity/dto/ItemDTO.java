package ru.x5.markusdata.entity.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import ru.x5.markusdata.entity.jpa.Gtins;

import java.util.List;

@Data
public class ItemDTO {

    @JsonProperty(value = "PLU_ID")
    private String pluId;

    @JsonProperty(value = "FULLNAME")
    private String fullname;

    @JsonProperty(value = "UNITS_IN_PACKAGING")
    private Integer unitsInPackaging;

    @JsonProperty(value = "PACKAGE_ID")
    private String packageId;

    @JsonProperty(value = "PACKAGE_CH_ID")
    private String packageChId;

    @JsonProperty(value = "PACKAGE_LEVEL")
    private String packageLevel;

    @JsonProperty(value = "AMOUNT_IN_PACKAGING")
    private Integer amountInPackaging;

    @JsonProperty(value = "GTINS")
    private List<GtinsDTO> gtinsList;
}