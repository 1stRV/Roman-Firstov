package ru.x5.markusdata.service;


import ru.x5.markusdata.entity.jpa.Document;

public interface DocumentService {



    Document saveDocument(Document document);
}
