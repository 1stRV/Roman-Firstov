package ru.x5.markusdata.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.x5.markusdata.entity.jpa.Gtins;
import ru.x5.markusdata.repository.GtinsRestRepository;
import ru.x5.markusdata.service.GtinsService;

import java.util.List;

@Service
@RequiredArgsConstructor
public class GtinsServiceImpl implements GtinsService {
    private final GtinsRestRepository gtinsRestRepository;

    @Override
    public List<Gtins> findAllGtins() {
        return gtinsRestRepository.findAll();
    }
}
