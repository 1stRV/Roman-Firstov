package ru.x5.markusdata.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.x5.markusdata.entity.jpa.Document;
import ru.x5.markusdata.service.DocumentService;

@RestController
@RequestMapping("/documents")
@RequiredArgsConstructor
public class DoctorController {

    private final DocumentService documentService;

    @PostMapping
    public Document saveDocument(@RequestBody Document document) {
        return documentService.saveDocument(document);
    }
}
