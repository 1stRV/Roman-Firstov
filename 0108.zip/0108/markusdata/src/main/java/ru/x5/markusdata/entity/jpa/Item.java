package ru.x5.markusdata.entity.jpa;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

@Entity
@Data
public class Item {

    @Id
    @Column(name = "PLU_ID", nullable = false, length = 18, insertable = false, updatable = false)
    private String pluId;

    @Column(name = "FULLNAME", nullable = false, length = 132)
    private String fullname;

    @Column(name = "UNITS_IN_PACKAGING", length = 3)
    private Integer unitsInPackaging;

    @Column(name = "PACKAGE_ID", nullable = false, length = 20)
    private String packageId;

    @Column(name = "PACKAGE_CH_ID", nullable = false, length = 20)
    private String packageChId;

    @Column(name = "PACKAGE_LEVEL", length = 40)
    private String packageLevel;

    @Column(name = "AMOUNT_IN_PACKAGING", length = 5)
    private Integer amountInPackaging;

    @LastModifiedDate
    @Column(name = "LAST_MOD_DATE")
    private Timestamp lastModDate;

    @CreatedDate
    @Column(name = "FIRST_ADD_DATE")
    private Timestamp firstAddDate;

    @OneToMany(mappedBy = "item", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    public Set<Gtins> gtins = new HashSet<>();
}