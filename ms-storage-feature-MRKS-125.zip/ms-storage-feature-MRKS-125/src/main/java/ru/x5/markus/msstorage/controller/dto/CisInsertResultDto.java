package ru.x5.markus.msstorage.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Результаты вставки КИЗ
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CisInsertResultDto {
    private List<String> cisList;
    private Integer cisNumber;
}
