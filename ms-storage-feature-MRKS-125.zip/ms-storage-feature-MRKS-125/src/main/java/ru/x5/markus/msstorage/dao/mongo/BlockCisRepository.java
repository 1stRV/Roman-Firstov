package ru.x5.markus.msstorage.dao.mongo;

import ru.x5.markus.msstorage.dao.model.CisBlockModel;

public interface BlockCisRepository extends CisRepository<CisBlockModel> {
}
