package ru.x5.markus.msstorage.dao.oracle;

import io.ebean.EbeanServer;
import io.ebean.EbeanServerFactory;
import io.ebean.config.ServerConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

@Configuration
public class EbeanConfiguration {

    @Bean
    public EbeanServer ebeanServer(EbeanSpringProperties ebeanSpringProperties) {
        ServerConfig cfg = new ServerConfig();

        Properties properties = new Properties();
        properties.put("datasource.db.username", ebeanSpringProperties.getUsername());
        properties.put("datasource.db.password", ebeanSpringProperties.getPassword());
        properties.put("datasource.db.databaseUrl", ebeanSpringProperties.getUrl());
        properties.put("datasource.db.databaseDriver", ebeanSpringProperties.getDriverClassName());

        cfg.loadFromProperties(properties);
        return EbeanServerFactory.create(cfg);
    }

}
