package ru.x5.markus.msstorage.dao.model;

import lombok.Builder;
import org.springframework.data.mongodb.core.mapping.Document;
import ru.x5.markus.lib.motpsender.dao.dto.enums.EnumPackageType;

@Document("cisPacks")
public class CisPackModel extends CisUndefinedModel {

    @Builder(builderMethodName = "cisPackBuilder")
    public CisPackModel(String cis, String parentCis, String status, Long idHeader, EnumPackageType packageType) {
        super(cis, parentCis, status, idHeader, packageType);
    }
}
