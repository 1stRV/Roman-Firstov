package ru.x5.markus.msstorage.dao.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;
import ru.x5.markus.lib.motpsender.dao.dto.enums.EnumPackageType;

import javax.persistence.Id;

@Document("cisUndefineds")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CisUndefinedModel {
    @Id
    private String cis;
    private String parentCis;
    private String status;
    private Long idHeader;
    protected EnumPackageType packageType;
}
