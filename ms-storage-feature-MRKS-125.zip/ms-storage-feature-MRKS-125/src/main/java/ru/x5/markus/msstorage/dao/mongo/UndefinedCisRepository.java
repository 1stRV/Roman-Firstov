package ru.x5.markus.msstorage.dao.mongo;

import ru.x5.markus.msstorage.dao.model.CisUndefinedModel;

public interface UndefinedCisRepository extends CisRepository<CisUndefinedModel> {
}
