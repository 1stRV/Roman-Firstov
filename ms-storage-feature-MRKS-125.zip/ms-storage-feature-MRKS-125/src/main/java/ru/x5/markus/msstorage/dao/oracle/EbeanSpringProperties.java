package ru.x5.markus.msstorage.dao.oracle;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Для использования в ebean конфигураций и профилей Spring
 */
@Component
@ConfigurationProperties(prefix = "spring.datasource")
@Data
public class EbeanSpringProperties {
    private String username;
    private String password;
    private String url;
    private String driverClassName;
}
