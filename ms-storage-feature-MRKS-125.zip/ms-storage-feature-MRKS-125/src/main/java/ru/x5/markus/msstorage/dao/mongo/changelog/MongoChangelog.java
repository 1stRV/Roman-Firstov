package ru.x5.markus.msstorage.dao.mongo.changelog;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.mongodb.client.MongoDatabase;

@ChangeLog
public class MongoChangelog {

    private static final String CIS_UNDEFINEDS = "cisUndefineds";
    private static final String CIS_PACKS = "cisPacks";
    private static final String CIS_BLOCKS = "cisBlocks";
    private static final String CIS_BOXES = "cisBoxes";

    @ChangeSet(author = "Maksim.Seryakov", order = "001", id = "Create init collection")
    public void createCollection(MongoDatabase mongoDatabase) {
        mongoDatabase.createCollection(CIS_UNDEFINEDS);
    }

    @ChangeSet(author = "Maksim.Seryakov", order = "002", id = "Create cisPack collection")
    public void createCisCollections(MongoDatabase mongoDatabase) {
        mongoDatabase.createCollection(CIS_PACKS);
        mongoDatabase.createCollection(CIS_BLOCKS);
        mongoDatabase.createCollection(CIS_BOXES);
    }
}
