package ru.x5.markus.msstorage.service.converter;

import ru.x5.markus.msstorage.controller.dto.UPDDto;
import ru.x5.markus.msstorage.dao.model.CisUndefinedModel;
import ru.x5.markus.msstorage.dao.model.UPDModel;

import java.util.List;

public class UPDConverter {
    private UPDConverter() {
    }

    public static UPDModel dto2model(UPDDto updDto) {
        List<CisUndefinedModel> cisUndefinedModels = CisConverter.dto2CisUndefinedList(updDto.getCisDtoList());
        return UPDModel.builder().dateCreated(updDto.getDateCreated())
                .dateUpdated(updDto.getDateUpdated())
                .docType(updDto.getDocType())
                .guid(updDto.getGuid())
                .idClient(updDto.getIdClient())
                .idHeader(updDto.getIdHeader())
                .status(updDto.getStatus())
                .storeNumber(updDto.getStoreNumber())
                .ttn(updDto.getTtn())
                .ttnDate(updDto.getTtnDate())
                .cisUndefinedModelList(cisUndefinedModels)
                .build();
    }
}
