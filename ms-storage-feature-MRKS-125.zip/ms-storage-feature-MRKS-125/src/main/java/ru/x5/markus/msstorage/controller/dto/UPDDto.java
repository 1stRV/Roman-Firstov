package ru.x5.markus.msstorage.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UPDDto {
    private Long idHeader;
    private String guid;
    private Long storeNumber;
    private String status;
    private Long idClient;
    private String docType;
    private String ttn;
    private Timestamp ttnDate;
    private Timestamp dateCreated;
    private Timestamp dateUpdated;
    private List<CisDto> cisDtoList;
}
