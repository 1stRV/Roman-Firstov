package ru.x5.markus.msstorage.dao.mongo;

import ru.x5.markus.msstorage.dao.model.CisPackModel;

public interface PackCisRepository extends CisRepository<CisPackModel> {
}
