package ru.x5.markus.msstorage.dao.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "DOC_HEADERS")
public class UPDModel {
    @Id
    @Column(name = "ID_HEADER")
    private Long idHeader;
    @Column(name = "GUID")
    private String guid;
    @Column(name = "STORE_NUMBER")
    private Long storeNumber;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "ID_CLIENT")
    private Long idClient;
    @Column(name = "DOCTYPE")
    private String docType;
    @Column(name = "TTN")
    private String ttn;
    @Column(name = "TTN_DATE")
    private Timestamp ttnDate;
    @Column(name = "DT_CREATED")
    private Timestamp dateCreated;
    @Column(name = "DT_UPDATED")
    private Timestamp dateUpdated;
    @Transient
    private List<CisUndefinedModel> cisUndefinedModelList;
}
