package ru.x5.markus.msstorage.dao.mongo;

import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import ru.x5.markus.msstorage.dao.model.CisUndefinedModel;

import java.util.List;

public interface CisRepository<T extends CisUndefinedModel> extends MongoRepository<T, String> {
    @Query("{ 'idHeader' : ?0 }")
    List<T> findByIdHeader(Long idHeader);

    @DeleteQuery(value = "{ 'idHeader' : ?0 }")
    Long deleteByIdHeader(Long idHeader);

}
