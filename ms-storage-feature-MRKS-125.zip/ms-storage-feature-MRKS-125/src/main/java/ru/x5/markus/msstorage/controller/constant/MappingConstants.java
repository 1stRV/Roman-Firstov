package ru.x5.markus.msstorage.controller.constant;

public class MappingConstants {
    private MappingConstants() {
    }
        public static final String VERSION = "/api/v1";
        public static final String DOCUMENT = "/document";
        public static final String UPD = "/upd";
        public static final String CIS = "/cises";
        public static final String STATUS = "/status";
}
