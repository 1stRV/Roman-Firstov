package ru.x5.markus.msstorage.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.x5.markus.lib.motpsender.dao.dto.enums.EnumPackageType;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CisDto {
    private String cis;
    private String parentCis;
    private String status;
    private Long idHeader;
    private EnumPackageType packageType;
}
