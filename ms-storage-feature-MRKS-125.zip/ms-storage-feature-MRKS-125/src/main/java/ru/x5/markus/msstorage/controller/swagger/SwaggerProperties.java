package ru.x5.markus.msstorage.controller.swagger;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "x5.markus.msstorage.swagger")
@Data
public class SwaggerProperties {
    private String title;
    private String version;
    private String description;
}
