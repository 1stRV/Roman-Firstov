package ru.x5.markus.msstorage.service.converter;

import ru.x5.markus.msstorage.controller.dto.CisDto;
import ru.x5.markus.msstorage.dao.model.CisBlockModel;
import ru.x5.markus.msstorage.dao.model.CisBoxModel;
import ru.x5.markus.msstorage.dao.model.CisPackModel;
import ru.x5.markus.msstorage.dao.model.CisUndefinedModel;

import java.util.List;
import java.util.stream.Collectors;

public class CisConverter {
    private CisConverter() {
    }

    public static CisUndefinedModel dto2CisUndefinedModel(CisDto cisDto) {
        return CisUndefinedModel.builder().cis(cisDto.getCis())
                .idHeader(cisDto.getIdHeader())
                .status(cisDto.getStatus())
                .packageType(cisDto.getPackageType())
                .parentCis(cisDto.getParentCis())
                .build();
    }

    public static CisPackModel dto2CisPackModel(CisDto cisDto) {
        return CisPackModel.cisPackBuilder()
                .cis(cisDto.getCis())
                .idHeader(cisDto.getIdHeader())
                .status(cisDto.getStatus())
                .packageType(cisDto.getPackageType())
                .parentCis(cisDto.getParentCis())
                .build();
    }

    public static CisBlockModel dto2CisBlockModel(CisDto cisDto) {
        return CisBlockModel.cisBlockBuilder()
                .cis(cisDto.getCis())
                .idHeader(cisDto.getIdHeader())
                .status(cisDto.getStatus())
                .packageType(cisDto.getPackageType())
                .parentCis(cisDto.getParentCis())
                .build();
    }

    public static CisBoxModel dto2CisBoxModel(CisDto cisDto) {
        return CisBoxModel.cisBoxBuilder()
                .cis(cisDto.getCis())
                .idHeader(cisDto.getIdHeader())
                .status(cisDto.getStatus())
                .packageType(cisDto.getPackageType())
                .parentCis(cisDto.getParentCis())
                .build();
    }

    public static CisDto cisUndefinedModel2dto(CisUndefinedModel cisUndefinedModel) {
        return CisDto.builder().cis(cisUndefinedModel.getCis())
                .idHeader(cisUndefinedModel.getIdHeader())
                .status(cisUndefinedModel.getStatus())
                .packageType(cisUndefinedModel.getPackageType())
                .parentCis(cisUndefinedModel.getParentCis())
                .build();
    }

    public static List<CisUndefinedModel> dto2CisUndefinedList(List<CisDto> cisDtoList) {
        return cisDtoList.stream().map(CisConverter::dto2CisUndefinedModel).collect(Collectors.toList());
    }

    public static List<CisDto> model2dtoList(List<CisUndefinedModel> cisUndefinedModelList) {
        return cisUndefinedModelList.stream().map(CisConverter::cisUndefinedModel2dto).collect(Collectors.toList());
    }
}
