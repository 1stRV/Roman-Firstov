package ru.x5.markus.msstorage.service;

import io.ebean.EbeanServer;
import io.ebean.Transaction;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.x5.markus.msstorage.controller.dto.CisDto;
import ru.x5.markus.msstorage.controller.dto.CisInsertResultDto;
import ru.x5.markus.msstorage.controller.dto.UPDDto;
import ru.x5.markus.msstorage.dao.model.CisUndefinedModel;
import ru.x5.markus.msstorage.dao.model.UPDModel;
import ru.x5.markus.msstorage.dao.mongo.BlockCisRepository;
import ru.x5.markus.msstorage.dao.mongo.BoxCisRepository;
import ru.x5.markus.msstorage.dao.mongo.PackCisRepository;
import ru.x5.markus.msstorage.dao.mongo.UndefinedCisRepository;
import ru.x5.markus.msstorage.service.converter.CisConverter;
import ru.x5.markus.msstorage.service.converter.UPDConverter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Log4j2
@Service
//todo: Добавить тесты после уточнения моделей
public class UPDService {

    @Autowired
    EbeanServer ebeanServer;

    @Autowired
    UndefinedCisRepository undefinedCisRepository;

    @Autowired
    PackCisRepository packCisRepository;

    @Autowired
    BoxCisRepository boxCisRepository;

    @Autowired
    BlockCisRepository blockCisRepository;

    @Transactional
    public List<CisDto> createUPD(UPDDto updDto) {
        log.debug("Incoming service UPD {}", updDto);
        UPDModel updModel = UPDConverter.dto2model(updDto);
        try (Transaction transaction = ebeanServer.beginTransaction()) {
            ebeanServer.insert(updModel);
            updModel.getCisUndefinedModelList().forEach(cisModel -> cisModel.setIdHeader(updDto.getIdHeader()));
            List<CisUndefinedModel> cisUndefinedModels = undefinedCisRepository.insert(updModel.getCisUndefinedModelList());
            transaction.commit();
            return CisConverter.model2dtoList(cisUndefinedModels);
        }
    }

    public List<String> getUndefinedCisesByUpd (Long updIdHeader) {
        List<CisUndefinedModel> cisUndefinedModelList = undefinedCisRepository.findByIdHeader(updIdHeader);
        return cisUndefinedModelList.stream().map(CisUndefinedModel::getCis).collect(Collectors.toList());
    }

    public CisInsertResultDto addCises(List<CisDto> cisDtoList) {
        List<String> resultCisList = new ArrayList<>();
        for (CisDto cisDto : cisDtoList) {
            switch (cisDto.getPackageType()) {
                case BOX:
                    resultCisList.add(boxCisRepository.insert(CisConverter.dto2CisBoxModel(cisDto)).getCis());
                    break;
                case BLOCK:
                    resultCisList.add(blockCisRepository.insert(CisConverter.dto2CisBlockModel(cisDto)).getCis());
                    break;
                case PACK:
                    resultCisList.add(packCisRepository.insert(CisConverter.dto2CisPackModel(cisDto)).getCis());
                    break;
                //todo: Разобраться с типами упаковок. В МОТП нет данных
                case UNIT:
                    break;
                case LEVEL1:
                    break;
            }
        }
        return new CisInsertResultDto(resultCisList, resultCisList.size());
    }

    @Transactional
    public Long deleteUPD(Long updIdHeader) {
        try (Transaction transaction = ebeanServer.beginTransaction()) {
            ebeanServer.delete(UPDModel.class, updIdHeader);
            Long result = undefinedCisRepository.deleteByIdHeader(updIdHeader)
                    + packCisRepository.deleteByIdHeader(updIdHeader)
                    + blockCisRepository.deleteByIdHeader(updIdHeader)
                    + boxCisRepository.deleteByIdHeader(updIdHeader);
            transaction.commit();
            return result;
        }
    }

    public Integer updateUpdDtoStatus(Long updIdHeader, String status) {
        return ebeanServer.update(UPDModel.class).set("status", status).where().idEq(updIdHeader).update();
    }
}
