package ru.x5.markus.msstorage.dao.mongo.config;

import com.github.mongobee.Mongobee;
import com.mongodb.MongoClient;
import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.MongoTransactionManager;

@Configuration
public class MongoConfiguration {

    private static final String CHANGELOG = "ru.x5.markus.msstorage.dao.mongo.changelog";

    @Bean
    MongoTransactionManager transactionManager(MongoDbFactory dbFactory) {
        return new MongoTransactionManager(dbFactory);
    }

    @Bean
    public Mongobee mongobee(Environment environment, MongoProperties mongoProperties, MongoClient mongoClient){
        Mongobee runner = new Mongobee(mongoClient);
        runner.setDbName(mongoProperties.getMongoClientDatabase());
        runner.setSpringEnvironment(environment);
        runner.setChangeLogsScanPackage(CHANGELOG);
        return runner;
    }
}
