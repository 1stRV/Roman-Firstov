package ru.x5.markus.msstorage.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.x5.markus.msstorage.controller.dto.CisDto;
import ru.x5.markus.msstorage.controller.dto.CisInsertResultDto;
import ru.x5.markus.msstorage.controller.dto.UPDDto;
import ru.x5.markus.msstorage.service.UPDService;

import java.util.List;

import static ru.x5.markus.msstorage.controller.constant.MappingConstants.*;

@RestController
@RequestMapping(VERSION + UPD)
public class UPDController {

    @Autowired
    UPDService updService;

    /**
     * Сохранение первичного документа УПД. Сохранение КИЗ происходит в отдельную коллекцию, без указания типа КИЗ
     * @param updDto документ УПД с первичными КИЗами
     */
    @PostMapping(DOCUMENT)
    public List<CisDto> createUPD(@RequestBody UPDDto updDto) {
        return updService.createUPD(updDto);
    }

    /**
     * Получение списка КИЗов по номеру документа УПД. КИЗы берутся из коллекции без типов
     * @param updIdHeader номер документа УПД
     * @return перечень КИЗов принадлежащих УПД до обогащения
     */
    @GetMapping(CIS + "/{updIdHeader}")
    public List<String> getUndefinedCis(@PathVariable Long updIdHeader) {
        return updService.getUndefinedCisesByUpd(updIdHeader);
    }

    /**
     * Добавление КИЗов с обязательным указанием их типа
     * @param cisDtoList список КИЗов с указанием их типа
     * @return перечень добавленных КИЗов и их количество
     */
    @PostMapping(CIS)
    public CisInsertResultDto addCises(@RequestBody List<CisDto> cisDtoList) {
        return updService.addCises(cisDtoList);
    }

    /**
     * Удаление первичного документа УПД со всеми КИЗами
     * @param updIdHeader номер документа УПД
     * @return количество удаленных КИЗ
     */
    @DeleteMapping(DOCUMENT + "/{updIdHeader}")
    public Long deleteUPD(@PathVariable Long updIdHeader) {
        return updService.deleteUPD(updIdHeader);
    }


    /**
     * Смена статуса документа
     * @param updIdHeader Номер документа
     * @param updStatus Статус документа
     * @return количество измененных строк
     */
    @PutMapping(DOCUMENT + "/{updIdHeader}" + STATUS + "/{updStatus}")
            public Integer updateUpdStatus(@PathVariable Long updIdHeader,
                                           @PathVariable String updStatus) {
        return updService.updateUpdDtoStatus(updIdHeader, updStatus);
    }
}
