package ru.x5.markusdata.entity.jpa;
import lombok.Data;
import javax.persistence.*;
import java.util.List;

@Data
@Entity
public class Document {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private String id;

    private String strStr;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "document")
    private List<Preview> previews;


    @PrePersist
    private void prePersist() {
        previews.forEach(comment -> comment.setDocument(this));
    }

}
