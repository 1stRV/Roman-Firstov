package ru.x5.markusdata.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.x5.markusdata.entity.jpa.Document;
import ru.x5.markusdata.repository.DocumentRepository;
import ru.x5.markusdata.service.DocumentService;
@Service
@RequiredArgsConstructor
public class DocumentServiceImpl implements DocumentService {

    private final DocumentRepository documentRepository;

    @Override
    public Document saveDocument(Document document) {


        return documentRepository.save(document);
//        document.setPreviews(Arrays.asList(previewService.generateDefaultPreview(document)));
    }
}
