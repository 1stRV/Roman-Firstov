package ru.x5.markusdata.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.x5.markusdata.entity.jpa.Preview;

public interface PreviewRepository extends JpaRepository<Preview, String> {
}
