package ru.x5.markusdata.service;

import ru.x5.markusdata.entity.jpa.Gtins;

import java.util.List;

public interface GtinsService {
    List<Gtins> findAllGtins();
}
