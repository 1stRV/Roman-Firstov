package ru.x5.markusdata.service.impl;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import ru.x5.markusdata.entity.dto.GtinsDTO;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.jpa.Gtins;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.repository.GtinsRestRepository;
import ru.x5.markusdata.repository.ItemRestRepository;
import ru.x5.markusdata.service.ItemService;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ItemServiceImpl implements ItemService {

    private final ItemRestRepository itemRestRepository;
    private final GtinsRestRepository gtinsRestRepository;

    @Override
    public List<Item> findAllItem() {
        return itemRestRepository.findAll();
    }

        private ModelMapper modelMapper = new ModelMapper();

    @Override
    public Item saveItem(ItemDTO itemDTO) {
        Item itemSaved = itemRestRepository.save(convertItemDTOToEntity(itemDTO));
        return itemSaved;
    }

    private Item convertItemDTOToEntity(ItemDTO itemDTO) {

        List<GtinsDTO> gtinsDTOList = itemDTO.getGtins();



        List<Gtins> gtinsList =
                gtinsDTOList
                        .stream()
                        .map(gtins -> modelMapper.map(gtins, Gtins.class))
                        .collect(Collectors.toList());





        Item item = modelMapper.map(itemDTO, Item.class);

        item.setGtins(gtinsList);


//        item.setGtins(this.convertGtinsDTOToEntity(itemDTO.getGtinsList()));
        return item;
    }

//    @Override
//    public Item saveItem(Item item) {
//        return itemRestRepository.save(item);
//    }
}
