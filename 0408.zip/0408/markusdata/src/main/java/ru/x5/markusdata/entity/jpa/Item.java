package ru.x5.markusdata.entity.jpa;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
public class Item {

    @Id
//    @Column(name = "PLU_ID", nullable = false, length = 18, insertable = false, updatable = false)
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;

    //    @Column(name = "FULLNAME", nullable = false, length = 132)
    private String fullname;

    //    @Column(name = "UNITS_IN_PACKAGING", length = 3)
    private Integer unitsInPackaging;

    //    @Column(name = "PACKAGE_ID", nullable = false, length = 20)
    private String packageId;

    //    @Column(name = "PACKAGE_CH_ID", nullable = false, length = 20)
    private String packageChId;

    //    @Column(name = "PACKAGE_LEVEL", length = 40)
    private String packageLevel;

    //    @Column(name = "AMOUNT_IN_PACKAGING", length = 5)
    private Integer amountInPackaging;

//    @LastModifiedDate
//    @Column(name = "LAST_MOD_DATE")
//    private Timestamp lastModDate;
//
//    @CreatedDate
//    @Column(name = "FIRST_ADD_DATE")
//    private Timestamp firstAddDate;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "item")
    public List<Gtins> gtins;

    @PrePersist
    private void prePersist() {
        gtins.forEach(gtin -> gtin.setItem(this));
    }
}