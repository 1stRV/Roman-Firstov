package ru.x5.markusdata.helpers;

//public class ItemUrlSerializer extends JsonSerializer<Item> {
//    @Override
//    public void serialize(Item item, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
//        jsonGenerator.writeString("/item/" + item.getPluId());
//    }
//}
