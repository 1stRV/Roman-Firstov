package ru.x5.markusdata.service;

//import ru.x5.markusdata.entity.dto.ItemDTO;

import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.jpa.Item;

import java.util.List;

public interface ItemService {
            Item saveItem(ItemDTO itemDTO);
//    Item saveItem(Item item);
    List<Item> findAllItem();
}
