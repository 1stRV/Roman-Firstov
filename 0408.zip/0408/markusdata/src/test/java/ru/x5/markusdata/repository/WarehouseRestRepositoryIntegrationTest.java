//package ru.x5.markusdata.repository;
//
//import org.apache.commons.io.IOUtils;
//import org.assertj.core.api.Assertions;
//import org.junit.Before;
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.core.io.Resource;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import ru.x5.markusdata.entity.jpa.BalanceUnit;
//import ru.x5.markusdata.entity.jpa.Warehouse;
//
//import java.io.IOException;
//import java.util.Optional;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertTrue;
//
//
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//public class WarehouseRestRepositoryIntegrationTest extends AbstractRestRepositoryTest {
//    @Autowired
//    private WarehouseRestRepository warehouseRestRepository;
//
//    @Value("classpath:json/warehouse.json")
//    private Resource warehouseInsertRequestResource;
//
//    @Value("classpath:json/warehouse-change.json")
//    private Resource warehouseUpdateRequestResource;
//
//    @Value("classpath:json/warehouse-long-field.json")
//    private Resource warehouseLongFieldRequestResource;
//
//    @Value("classpath:json/warehouse-inn-null-field.json")
//    private Resource warehouseNullFieldRequestResource;
//
//
//    @Value("classpath:json/balance-unit.json")
//    private Resource balanceUnitInsertRequestResource;
//
//    private String warehouseInsertRequest;
//
//    private String warehouseUpdateRequest;
//
//    private String warehouseLongFieldRequest;
//
//    private String warehouseNullFieldRequest;
//
//    private String balanceUnitInsertRequest;
//
//    @Before
//    public void init() throws IOException {
//        balanceUnitInsertRequest = IOUtils.toString(balanceUnitInsertRequestResource.getInputStream(), "UTF-8");
//        warehouseInsertRequest = IOUtils.toString(warehouseInsertRequestResource.getInputStream(), "UTF-8");
//        warehouseUpdateRequest = IOUtils.toString(warehouseUpdateRequestResource.getInputStream(), "UTF-8");
//        warehouseLongFieldRequest = IOUtils.toString(warehouseLongFieldRequestResource.getInputStream(), "UTF-8");
//        warehouseNullFieldRequest = IOUtils.toString(warehouseNullFieldRequestResource.getInputStream(), "UTF-8");
//    }
//
//    @Test
//    public void warehouseRepositoryInsert() throws Exception {
//        BalanceUnit balanceUnitInsertExpected = objectMapper.readValue(balanceUnitInsertRequest, BalanceUnit.class);
//        restTemplate.postForEntity("/balanceunit", balanceUnitInsertExpected, Object.class);
//
//        Warehouse warehouseInsertExpected = objectMapper.readValue(warehouseInsertRequest, Warehouse.class);
//        ResponseEntity responseEntityInsert = restTemplate.postForEntity("/warehouse", warehouseInsertRequest, Object.class);
//        assertEquals(HttpStatus.CREATED, responseEntityInsert.getStatusCode());
//
//        Optional<Warehouse> optionalWarehouse = warehouseRestRepository.findById(warehouseInsertExpected.getMdmId());
//        assertTrue(optionalWarehouse.isPresent());
//        Assertions.assertThat(optionalWarehouse.get()).isEqualToIgnoringNullFields(warehouseInsertExpected);
//    }
//
//    @Test
//    public void warehouseRepositoryUpdate() throws Exception {
//        BalanceUnit balanceUnitInsertExpected = objectMapper.readValue(balanceUnitInsertRequest, BalanceUnit.class);
//        restTemplate.postForEntity("/balanceunit", balanceUnitInsertExpected, Object.class);
//
//        Warehouse warehouseInsertExpected = objectMapper.readValue(warehouseInsertRequest, Warehouse.class);
//        restTemplate.postForEntity("/warehouse", warehouseInsertRequest, Object.class);
//
//        Warehouse warehouseUpdateExpected = objectMapper.readValue(warehouseUpdateRequest, Warehouse.class);
//        ResponseEntity responseEntityUpdate = restTemplate.postForEntity("/warehouse", warehouseUpdateRequest, Object.class);
//        assertEquals(HttpStatus.CREATED, responseEntityUpdate.getStatusCode());
//
//        Assertions.assertThat(warehouseInsertExpected).isNotEqualTo(warehouseUpdateExpected);
//        Optional<Warehouse> optionalWarehouse = warehouseRestRepository.findById(warehouseUpdateExpected.getMdmId());
//        assertTrue(optionalWarehouse.isPresent());
//        Assertions.assertThat(optionalWarehouse.get()).isEqualToIgnoringNullFields(warehouseUpdateExpected);
//    }
//
//    @Test
//    public void longFieldRequest() {
//        ResponseEntity responseEntity = restTemplate.postForEntity("/warehouse", warehouseLongFieldRequest, Object.class);
//        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());
//    }
//
//    @Test
//    public void nullFieldRequest() {
//        ResponseEntity responseEntity = restTemplate.postForEntity("/warehouse", warehouseNullFieldRequest, Object.class);
//        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());
//    }
//}