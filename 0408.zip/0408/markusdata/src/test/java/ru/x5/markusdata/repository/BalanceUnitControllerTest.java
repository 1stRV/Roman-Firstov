//package ru.x5.markusdata.repository;
//
//import org.springframework.beans.factory.annotation.Value;
//
//import org.apache.commons.io.IOUtils;
//import org.junit.Before;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.core.io.Resource;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import java.io.IOException;
//import java.nio.charset.StandardCharsets;
//
////import org.assertj.core.api.Assertions;
//@RunWith(SpringRunner.class)
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//public class BalanceUnitControllerTest {
//
//    @Autowired
//    private BalanceUnitRestRepository balanceUnitRestRepository;
//
//    @Value("classpath:json/balance-unit.json")
//    private Resource balanceUnitInsertRequestResource;
//
//    @Value("classpath:json/balance-unit-change.json")
//    private Resource balanceUnitUpdateRequestResource;
//
//    @Value("classpath:json/balance-unit-long-field.json")
//    private Resource balanceUnitLongFieldRequestResource;
//
//    @Value("classpath:json/balance-unit-null-name-field.json")
//    private Resource balanceUnitNullFieldRequestResource;
//
//    private String balanceUnitInsertRequest;
//
//    private String balanceUnitUpdateRequest;
//
//    private String balanceUnitLongFieldRequest;
//
//    private String balanceUnitNullFieldRequest;
//
//    @Before
//    public void init() throws IOException {
//        balanceUnitInsertRequest = IOUtils.toString(balanceUnitInsertRequestResource.getInputStream(), StandardCharsets.UTF_8);
//        balanceUnitUpdateRequest = IOUtils.toString(balanceUnitUpdateRequestResource.getInputStream(), StandardCharsets.UTF_8);
//        balanceUnitLongFieldRequest = IOUtils.toString(balanceUnitLongFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
//        balanceUnitNullFieldRequest = IOUtils.toString(balanceUnitNullFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
//    }
//}
