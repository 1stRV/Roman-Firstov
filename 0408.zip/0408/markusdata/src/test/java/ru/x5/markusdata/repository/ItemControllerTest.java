//package ru.x5.markusdata.repository;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import lombok.RequiredArgsConstructor;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.core.io.Resource;
//import org.springframework.http.MediaType;
//import org.springframework.test.context.junit4.SpringRunner;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.web.context.WebApplicationContext;
//
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;
//import java.io.IOException;
//import java.nio.charset.StandardCharsets;
//import java.util.Optional;
//import org.apache.commons.io.IOUtils;
////import org.assertj.core.api.Assertions;
//@RunWith(SpringRunner.class)
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//public class ItemControllerTest {
//    private static final ObjectMapper objectMapper = new ObjectMapper();
//    private static final MediaType contentType = MediaType.APPLICATION_JSON_UTF8;
//    private MockMvc mockMvc;
//
//    @Autowired
//    private WebApplicationContext webApplicationContext;
//
//    @Value("classpath:json/item.json")
//    private Resource itemInsertRequestResource;
//
//    @Value("classpath:json/item-change.json")
//    private Resource itemUpdateRequestResource;
//
//    @Value("classpath:json/item-long-field.json")
//    private Resource itemLongFieldRequestResource;
//
//    @Value("classpath:json/item-package-id-null-field.json")
//    private Resource itemNullFieldRequestResource;
//
//    private String itemInsertRequest;
//
//    private String itemUpdateRequest;
//
//    private String itemLongFieldRequest;
//
//    private String itemNullFieldRequest;
//
//    public ItemControllerTest() {
//    }
//
//    @Before
//    public void init() throws Exception {
//        this.mockMvc = webAppContextSetup(webApplicationContext).build();
//        itemInsertRequest = IOUtils.toString(itemInsertRequestResource.getInputStream(), StandardCharsets.UTF_8);
//        itemUpdateRequest = IOUtils.toString(itemUpdateRequestResource.getInputStream(), StandardCharsets.UTF_8);
//        itemLongFieldRequest = IOUtils.toString(itemLongFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
//        itemNullFieldRequest = IOUtils.toString(itemNullFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
//    }
//
//
////    @Test
////    public void itemRepositoryInsert() throws Exception {
////        mockMvc.perform(post("/api/item")
////                .content(itemInsertRequest)
////                .contentType(contentType))
////                .andExpect(status().isOk());
////    }
//
//}
