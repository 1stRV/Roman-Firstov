package ru.x5.markusdata.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import ru.x5.markusdata.entity.jpa.BalanceUnit;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.entity.jpa.Warehouse;
import ru.x5.markusdata.service.MarkusDataService;

import java.util.List;


@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class MarkusDataController {

    private final MarkusDataService markusDataService;

    @PostMapping(value = "/balanceUnit")
    public BalanceUnit saveBalanceUnit(@RequestBody BalanceUnit balanceUnit) {
        return markusDataService.saveBalanceUnit(balanceUnit);
    }

    @GetMapping(value = "/balanceUnits")
    public List<BalanceUnit> findAllBalanceUnit() {
        return markusDataService.findAllBalanceUnit();
    }

    @PostMapping(value = "/item")
    public Item saveItem(@RequestBody Item item) {
        return markusDataService.saveItem(item);
    }

    @GetMapping(value = "/items")
    public List<Item> findAllItem() {
        return markusDataService.findAllItem();
    }

    @PostMapping(value = "/warehouse")
    public Warehouse saveWarehouse(@RequestBody Warehouse warehouse) {
        return markusDataService.saveWarehouse(warehouse);
    }

    @GetMapping(value = "/warehouses")
    public List<Warehouse> findAllWarehouse() {
        return markusDataService.findAllWarehouse();
    }

}