
package ru.x5.markusdata.entity.jpa;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.security.Timestamp;
import java.time.ZonedDateTime;
import java.util.Date;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
public class Gtins {
    //    @JsonProperty(value = "GTIN")
//    @Column(name = "GTIN", nullable = false, length = 18)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;

//    @JsonProperty(value = "PLU_ID")
//    @Column(name = "PLU_ID", length = 18, insertable = false, updatable = false)
//    private String pluId;

    //    @JsonProperty(value = "BAR_CODE_TYPE")
//    @Column(name = "BAR_CODE_TYPE")
    private String barCodeType;

    //    @JsonProperty(value = "TABACCO_MRC")
//    @Column(name = "TABACCO_MRC", length = 8)
    private BigDecimal tabaccoMrc;

    //    @JsonProperty(value = "TABACCO_DATE_MRC")
//    @Column(name = "TABACCO_DATE_MRC")
    private ZonedDateTime tabaccoDateMrc;

//    @LastModifiedDate
////    @Column(name = "LAST_MOD_DATE")
//    private Timestamp lastModDate;
//
//    @CreatedDate
////    @Column(name = "FIRST_ADD_DATE")
//    private Timestamp firstAddDate;

    @ManyToOne
    @JsonIgnore
    private Item item;
}