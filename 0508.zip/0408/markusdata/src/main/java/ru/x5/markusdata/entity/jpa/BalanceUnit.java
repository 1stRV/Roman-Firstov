package ru.x5.markusdata.entity.jpa;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import java.sql.Timestamp;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Data
public class BalanceUnit {

    @Id
    @JsonProperty(value = "MDM_ID")
    @Column(name = "MDM_ID", nullable = false, length = 5)
    private String mdmId;

    @JsonProperty(value = "NAME")
    @Column(name = "NAME", nullable = false)
    private String name;

    @JsonProperty(value = "INN")
    @Column(name = "INN", nullable = false, length = 12)
    private String inn;

//    @LastModifiedDate
////    @Column(name = "LAST_MOD_DATE")
//    private Timestamp lastModDate;
//
//    @CreatedDate
////    @Column(name = "FIRST_ADD_DATE")
//    private Timestamp firstAddDate;
}

