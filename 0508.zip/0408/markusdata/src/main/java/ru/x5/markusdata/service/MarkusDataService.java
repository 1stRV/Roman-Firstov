package ru.x5.markusdata.service;

import ru.x5.markusdata.entity.jpa.BalanceUnit;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.entity.jpa.Warehouse;

import java.util.List;

public interface MarkusDataService {

    Item saveItem(Item item);

    List<Item> findAllItem();

    BalanceUnit saveBalanceUnit(BalanceUnit balanceUnit);

    List<BalanceUnit> findAllBalanceUnit();

    Warehouse saveWarehouse(Warehouse warehouse);

    List<Warehouse> findAllWarehouse();
}
