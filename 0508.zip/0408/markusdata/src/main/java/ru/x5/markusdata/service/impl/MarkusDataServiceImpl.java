package ru.x5.markusdata.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.x5.markusdata.entity.jpa.BalanceUnit;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.entity.jpa.Warehouse;
import ru.x5.markusdata.repository.BalanceUnitRepository;
import ru.x5.markusdata.repository.ItemRepository;
import ru.x5.markusdata.repository.WarehouseRepository;
import ru.x5.markusdata.service.MarkusDataService;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MarkusDataServiceImpl implements MarkusDataService {
    private final BalanceUnitRepository balanceUnitRepository;
    private final ItemRepository itemRepository;
    private final WarehouseRepository warehouseRepository;

    @Override
    public BalanceUnit saveBalanceUnit(BalanceUnit balanceUnit) {
        return balanceUnitRepository.save(balanceUnit);
    }

    @Override
    public List<BalanceUnit> findAllBalanceUnit() {
        return balanceUnitRepository.findAll();
    }

    @Override
    public Item saveItem(Item item) {
        return itemRepository.save(item);
    }

    @Override
    public List<Item> findAllItem() {
        return itemRepository.findAll();
    }

    @Override
    public Warehouse saveWarehouse(Warehouse warehouse) {
        return warehouseRepository.save(warehouse);
    }

    @Override
    public List<Warehouse> findAllWarehouse() {
        return warehouseRepository.findAll();
    }
}
