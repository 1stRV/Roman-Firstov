package ru.x5.markusdata.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultHandler;
import org.springframework.web.context.WebApplicationContext;
import ru.x5.markusdata.MarkusdataApplication;
import ru.x5.markusdata.entity.jpa.BalanceUnit;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MarkusdataApplication.class)
public class BalanceUnitControllerTest {
    private MockMvc mockMvc;
    private static final MediaType contentType = MediaType.APPLICATION_JSON_UTF8;
    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    private BalanceUnitRepository balanceUnitRepository;

    @Value("classpath:json/balance-unit.json")
    private Resource balanceUnitInsertRequestResource;

    @Value("classpath:json/balance-unit-change.json")
    private Resource balanceUnitUpdateRequestResource;

    @Value("classpath:json/balance-unit-long-field.json")
    private Resource balanceUnitLongFieldRequestResource;

    @Value("classpath:json/balance-unit-null-name-field.json")
    private Resource balanceUnitNullFieldRequestResource;

    private String balanceUnitInsertRequest;

    private String balanceUnitUpdateRequest;

    private String balanceUnitLongFieldRequest;

    private String balanceUnitNullFieldRequest;

    private BalanceUnit balanceUnitInsertExpected;
    @Before
    public void setUp() throws IOException {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
        balanceUnitInsertRequest = IOUtils.toString(balanceUnitInsertRequestResource.getInputStream(), StandardCharsets.UTF_8);
        balanceUnitUpdateRequest = IOUtils.toString(balanceUnitUpdateRequestResource.getInputStream(), StandardCharsets.UTF_8);
        balanceUnitLongFieldRequest = IOUtils.toString(balanceUnitLongFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
//        balanceUnitNullFieldRequest = IOUtils.toString(balanceUnitNullFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);

//      balanceUnitInsertExpected = new BalanceUnit();
//        balanceUnitInsertExpected.setInn("df");
//        balanceUnitInsertExpected.setMdmId("fd");
//        balanceUnitInsertExpected.setName("fdf");
       balanceUnitInsertExpected = objectMapper.readValue(balanceUnitInsertRequest, BalanceUnit.class);
    }

    @Test
    public void balanceUnitInsert() throws Exception {
       balanceUnitInsertExpected = objectMapper.readValue(balanceUnitInsertRequest, BalanceUnit.class);
        mockMvc.perform(post("/api/balanceUnit")
                .content(json(balanceUnitInsertExpected))
                .contentType(contentType))
                .andExpect(status().isOk());

        Optional<BalanceUnit> optionalBalanceUnit = balanceUnitRepository.findById(balanceUnitInsertExpected.getMdmId());
        assertTrue(optionalBalanceUnit.isPresent());
        Assertions.assertThat(optionalBalanceUnit.get()).isEqualToIgnoringNullFields(balanceUnitInsertExpected);
    }


        @Test
    public void balanceUnitRepositoryUpdate() throws Exception {
        balanceUnitInsertExpected = objectMapper.readValue(balanceUnitInsertRequest, BalanceUnit.class);


        BalanceUnit balanceUnitUpdateExpected = objectMapper.readValue(balanceUnitUpdateRequest, BalanceUnit.class);
            mockMvc.perform(post("/api/balanceUnit")
                    .content(json(balanceUnitUpdateExpected))
                    .contentType(contentType))
                    .andExpect(status().isOk());

        Assertions.assertThat(balanceUnitInsertExpected).isNotEqualTo(balanceUnitUpdateExpected);

        Optional<BalanceUnit> optionalBalanceUnit = balanceUnitRepository.findById(balanceUnitUpdateExpected.getMdmId());
        assertTrue(optionalBalanceUnit.isPresent());
        Assertions.assertThat(optionalBalanceUnit.get()).isEqualToIgnoringNullFields(balanceUnitUpdateExpected);
    }



    @Test
    public void longFieldRequest() throws Exception {
//        ResponseEntity responseEntity = restTemplate.postForEntity("/balanceunit", balanceUnitLongFieldRequest, Object.class);
//        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());

        BalanceUnit balanceUnitUpdateExpected = objectMapper.readValue(balanceUnitLongFieldRequest, BalanceUnit.class);
       mockMvc.perform(post("/api/balanceUnit")
                .content(json(balanceUnitUpdateExpected))
                .contentType(contentType))
                .andDo()




    }

//    @Test
//    public void nullFieldRequest() {
//        ResponseEntity responseEntity = restTemplate.postForEntity("/balanceunit", balanceUnitNullFieldRequest, Object.class);
//        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());
//    }







    private String json(Object o) throws IOException {
        return objectMapper.writeValueAsString(o);
    }
}
