//package ru.x5.markusdata.repository;
//
//import org.apache.commons.io.IOUtils;
//import org.assertj.core.api.Assertions;
//import org.junit.Before;
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.core.io.Resource;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import ru.x5.markusdata.entity.jpa.Item;
//
//import java.io.IOException;
//import java.nio.charset.StandardCharsets;
//import java.util.Optional;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertTrue;
//
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//public class ItemRestRepositoryIntegrationTest extends AbstractRestRepositoryTest {
//    @Autowired
//    private ItemRestRepository itemRestRepository;
//
//    @Autowired
//    private GtinsRestRepository gtinsRestRepository;
//
//    @Value("classpath:json/item.json")
//    private Resource itemInsertRequestResource;
//
//    @Value("classpath:json/item-change.json")
//    private Resource itemUpdateRequestResource;
//
//    @Value("classpath:json/item-long-field.json")
//    private Resource itemLongFieldRequestResource;
//
//    @Value("classpath:json/item-package-id-null-field.json")
//    private Resource itemNullFieldRequestResource;
//
//    private String itemInsertRequest;
//
//    private String itemUpdateRequest;
//
//    private String itemLongFieldRequest;
//
//    private String itemNullFieldRequest;
//
//    @Before
//    public void init() throws IOException {
//        itemInsertRequest = IOUtils.toString(itemInsertRequestResource.getInputStream(), StandardCharsets.UTF_8);
//        itemUpdateRequest = IOUtils.toString(itemUpdateRequestResource.getInputStream(), StandardCharsets.UTF_8);
//        itemLongFieldRequest = IOUtils.toString(itemLongFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
//        itemNullFieldRequest = IOUtils.toString(itemNullFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
//    }
//
//    @Test
//    public void itemRepositoryInsert() throws Exception {
//        Item itemInsertExpected = objectMapper.readValue(itemInsertRequest, Item.class);
//        ResponseEntity responseEntity = restTemplate.postForEntity("/item", itemInsertRequest, Object.class);
//        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
//
//        Optional<Item> optionalItem = itemRestRepository.findById(itemInsertExpected.getPluId());
//        assertTrue(optionalItem.isPresent());
//
//        Assertions.assertThat(optionalItem.get()).isEqualToIgnoringNullFields(itemInsertExpected);
//    }
//
//    @Test
//    public void itemRepositoryUpdate() throws Exception {
//        Item itemInsertExpected = objectMapper.readValue(itemInsertRequest, Item.class);
//        restTemplate.postForObject("/item", itemInsertRequest, Object.class);
//
//        Item itemUpdateExpected = objectMapper.readValue(itemUpdateRequest, Item.class);
//        restTemplate.postForObject("/item", itemUpdateRequest, Object.class);
//
//        Assertions.assertThat(itemInsertExpected).isNotEqualTo(itemUpdateExpected);
//        Optional<Item> optionalItem = itemRestRepository.findById(itemUpdateExpected.getPluId());
//        assertTrue(optionalItem.isPresent());
//        Assertions.assertThat(optionalItem.get()).isEqualToIgnoringNullFields(itemUpdateExpected);
//    }
//
//    @Test
//    public void longFieldRequest() {
//        ResponseEntity responseEntity = restTemplate.postForEntity("/item", itemLongFieldRequest, Object.class);
//        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());
//    }
//
//    @Test
//    public void nullFieldRequest() {
//        ResponseEntity responseEntity = restTemplate.postForEntity("/item", itemNullFieldRequest, Object.class);
//        assertEquals(HttpStatus.CONFLICT, responseEntity.getStatusCode());
//    }
//}