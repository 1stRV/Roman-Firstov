package ru.x5.markusdata.service;

import ru.x5.markusdata.entity.jpa.Item;

import java.util.List;

public interface ItemService {
    Item saveItem(Item item);

    List<Item> findAllItem();
}
