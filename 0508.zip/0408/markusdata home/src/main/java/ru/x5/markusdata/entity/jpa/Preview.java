package ru.x5.markusdata.entity.jpa;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import javax.persistence.*;

@Entity
@Data
public class Preview {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;

    private String str;

    @ManyToOne
    @JsonIgnore
    private Document document;
}