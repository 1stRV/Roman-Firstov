package ru.x5.markusdata.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.x5.markusdata.entity.jpa.Document;

public interface DocumentRepository extends JpaRepository<Document, String> {
}
