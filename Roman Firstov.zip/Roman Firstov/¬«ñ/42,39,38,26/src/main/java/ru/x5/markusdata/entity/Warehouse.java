package ru.x5.markusdata.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
public class Warehouse {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(nullable = false)
    private String mdmId;

    @Column(nullable = false)
    @JsonProperty("NAME")
    private String name;

    @ManyToOne
    @JoinColumn(name="balanceUnit", referencedColumnName="mdmId",nullable = false)
    @JsonProperty("BALANCE_UNIT")
    private BalanceUnit balanceUnit;

    @Column(nullable = false)
    @JsonProperty("INN")
    private String inn;

    @JsonProperty("KPP")
    private String kpp;

    @JsonProperty("IS_NO_TOBACCO")
    private String isNoTobacco;

    @Column(nullable = false)
    @JsonProperty("LAST_MOD_DATE")
    private Timestamp lastModDate;

    @Column(nullable = false)
    @JsonProperty("LAST_MOD_USER")
    private String lastModUser;

    @Column(nullable = false)
    @JsonProperty("FIRST_ADD_DATE")
    private Timestamp firstAddDate;
}


