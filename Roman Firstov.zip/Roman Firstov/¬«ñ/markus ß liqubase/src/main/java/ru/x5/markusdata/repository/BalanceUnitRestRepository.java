package ru.x5.markusdata.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import ru.x5.markusdata.entity.BalanceUnit;

@RepositoryRestResource(path = "balanceunit")
interface BalanceUnitRestRepository extends JpaRepository<BalanceUnit, Long> {
}
