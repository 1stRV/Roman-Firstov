package ru.x5.markusdata.repository;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import ru.x5.markusdata.entity.Gtins;

import java.io.IOException;
import java.net.URI;
import java.util.Optional;

public class GtinsRestRepositoryIntegrationTest extends AbstractRestRepositoryTest {
    @Autowired
    private GtinsRestRepository gtinsRestRepository;

    private static final String SERVICE_URI = "http://localhost:8088/gtins";

    @Value("classpath:json/g-tins.json")
    private Resource gtinsInsertRequestResource;

    @Value("classpath:json/g-tins-change.json")
    private Resource gtinsUpdateRequestResource;


    private String gtinsInsertRequest;

    private String gtinsUpdateRequest;

    @Before
    public void init() throws IOException {
        gtinsInsertRequest = IOUtils.toString(gtinsInsertRequestResource.getInputStream(), "UTF-8");
        gtinsUpdateRequest = IOUtils.toString(gtinsUpdateRequestResource.getInputStream(), "UTF-8");
    }

    @Test
    public void gtinsRepositoryInsertUpdateTest() throws Exception {
        Gtins gtinsInsertExpected = objectMapper.readValue(gtinsInsertRequest, Gtins.class);
        restTemplate.postForObject(new URI(SERVICE_URI), gtinsInsertRequest, Object.class);
        Gtins gtinsInsertActual = null;
        Optional<Gtins> optionalGtins = gtinsRestRepository.findById(gtinsInsertExpected.getGtin());
        if (optionalGtins.isPresent())
            gtinsInsertActual = optionalGtins.get();
        Assert.assertEquals(gtinsInsertExpected, gtinsInsertActual);

        Gtins gtinsUpdateExpected = objectMapper.readValue(gtinsUpdateRequest, Gtins.class);
        restTemplate.postForObject(new URI(SERVICE_URI), gtinsUpdateRequest, Object.class);
        Gtins gtinsUpdateActual = null;
        optionalGtins = gtinsRestRepository.findById(gtinsUpdateExpected.getGtin());
        if (optionalGtins.isPresent())
            gtinsUpdateActual = optionalGtins.get();
        Assert.assertEquals(gtinsUpdateExpected, gtinsUpdateActual);
    }
}