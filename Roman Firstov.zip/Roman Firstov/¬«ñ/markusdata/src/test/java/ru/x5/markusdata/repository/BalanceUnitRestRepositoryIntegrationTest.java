package ru.x5.markusdata.repository;

import org.apache.commons.io.IOUtils;
//import org.h2.jdbc.JdbcSQLIntegrityConstraintViolationException;
import org.h2.jdbc.JdbcSQLDataException;
import org.h2.jdbc.JdbcSQLIntegrityConstraintViolationException;
import org.hibernate.exception.DataException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
//import org.springframework.dao.DataIntegrityViolationException;
import javax.validation.Constraint;
import javax.validation.ConstraintViolationException;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import ru.x5.markusdata.entity.BalanceUnit;
import ru.x5.markusdata.entity.Item;

import static org.assertj.core.api.Assertions.*;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedHashMap;
import java.util.Optional;

//        org.h2.jdbc.JdbcSQLIntegrityConstraintViolationException


public class BalanceUnitRestRepositoryIntegrationTest extends AbstractRestRepositoryTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Autowired
    private BalanceUnitRestRepository balanceUnitRestRepository;

    private static final String SERVICE_URI = "http://localhost:8088/balanceunit";

    @Value("classpath:json/balance-unit.json")
    private Resource balanceUnitInsertRequestResource;

    @Value("classpath:json/balance-unit-change.json")
    private Resource balanceUnitUpdateRequestResource;

    //    @Value("classpath:json/balance-unit-null-field.json")
//    private Resource balanceUnitNullFieldRequestResource;
    @Value("classpath:json/balance-unit-long-field.json")
    private Resource balanceUnitLongFieldRequestResource;

    private String balanceUnitInsertRequest;

    private String balanceUnitUpdateRequest;

    //    private String balanceUnitNullFieldRequest;
    private String balanceUnitLongFieldRequest;

    @Before
    public void init() throws IOException {
        balanceUnitInsertRequest = IOUtils.toString(balanceUnitInsertRequestResource.getInputStream(), "UTF-8");
        balanceUnitUpdateRequest = IOUtils.toString(balanceUnitUpdateRequestResource.getInputStream(), "UTF-8");
        balanceUnitLongFieldRequest = IOUtils.toString(balanceUnitLongFieldRequestResource.getInputStream(), "UTF-8");

//        balanceUnitNullFieldRequest = IOUtils.toString(balanceUnitNullFieldRequestResource.getInputStream(), "UTF-8");
    }

    @Test
    public void balanceUnitRepositoryInsertUpdateTest() throws Exception {
        BalanceUnit balanceUnitInsertExpected = objectMapper.readValue(balanceUnitInsertRequest, BalanceUnit.class);
        restTemplate.postForObject(new URI(SERVICE_URI), balanceUnitInsertRequest, Object.class);
        BalanceUnit balanceUnitInsertActual = null;
        Optional<BalanceUnit> optionalBalanceUnit = balanceUnitRestRepository.findById(balanceUnitInsertExpected.getMdmId());
        if (optionalBalanceUnit.isPresent())
            balanceUnitInsertActual = optionalBalanceUnit.get();
        Assert.assertEquals(balanceUnitInsertExpected, balanceUnitInsertActual);

        BalanceUnit balanceUnitUpdateExpected = objectMapper.readValue(balanceUnitUpdateRequest, BalanceUnit.class);
        restTemplate.postForObject(new URI(SERVICE_URI), balanceUnitUpdateRequest, Object.class);
        BalanceUnit balanceUnitUpdateActual = null;
        optionalBalanceUnit = balanceUnitRestRepository.findById(balanceUnitUpdateExpected.getMdmId());
        if (optionalBalanceUnit.isPresent())
            balanceUnitUpdateActual = optionalBalanceUnit.get();
        Assert.assertEquals(balanceUnitUpdateExpected, balanceUnitUpdateActual);
    }

    @Test
    public void longFieldRequest(){
//        restTemplate.postForEntity(new URI(SERVICE_URI), balanceUnitLongFieldRequest, String.class);


        try {
            restTemplate.postForEntity(new URI(SERVICE_URI), balanceUnitLongFieldRequest, String.class);
        } catch (HttpClientErrorException e) {
            System.out.println(e.getMessage());
            System.out.println("999999999999999999999999999");
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }


//        Assert.assertEquals(409, result.getStatusCodeValue());
//        Assert.assertEquals(409, result.getBody());
    }

    //


//    @Test
//    public void  incorrect() throws URISyntaxException {
////        restTemplate.postForObject(new URI(SERVICE_URI), balanceUnitNullFieldRequest, Object.class);
//
//
//
////        assertThatThrownBy(() -> {
//            restTemplate.postForObject(new URI(SERVICE_URI), balanceUnitNullFieldRequest, BalanceUnit.class);
////        }).isInstanceOf(ConstraintViolationException.class);
//    }
//
//    @Test
//    public void  incorrect() throws URISyntaxException {
////        restTemplate.postForObject(new URI(SERVICE_URI), balanceUnitNullFieldRequest, Object.class);
//
//
//
////        assertThatThrownBy(() -> {
//        restTemplate.postForObject(new URI(SERVICE_URI), balanceUnitNullFieldRequest, BalanceUnit.class);
////        }).isInstanceOf(ConstraintViolationException.class);
//    }

}

//ложим в базу данные, проверяем, что они там лежат,+
// потом делаем обновление, проверяем, что там лежит те самые данные, которые мы закинули новые и проверяем по тому же айдишнику+


// 1)add @OneToMany
//2) add в @OneToMany(optional=false продебажить)
//3) новый тест: проверить что если сохраняешь без обязательного поля, то сохранить нельзя.