package ru.x5.markusdata.repository;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import ru.x5.markusdata.entity.Warehouse;

import java.io.IOException;
import java.net.URI;
import java.util.Optional;

public class WarehouseRestRepositoryIntegrationTest extends AbstractRestRepositoryTest {
    @Autowired
    private WarehouseRestRepository warehouseRestRepository;

    private static final String SERVICE_URI = "http://localhost:8088/warehouse";

    @Value("classpath:json/warehouse.json")
    private Resource warehouseInsertRequestResource;

    @Value("classpath:json/warehouse-change.json")
    private Resource warehouseUpdateRequestResource;


    private String warehouseInsertRequest;

    private String warehouseUpdateRequest;

    @Before
    public void init() throws IOException {
        warehouseInsertRequest = IOUtils.toString(warehouseInsertRequestResource.getInputStream(), "UTF-8");
        warehouseUpdateRequest = IOUtils.toString(warehouseUpdateRequestResource.getInputStream(), "UTF-8");
    }

    @Test
    public void gtinsRepositoryInsertUpdateTest() throws Exception {
        Warehouse warehouseInsertExpected = objectMapper.readValue(warehouseInsertRequest, Warehouse.class);
        restTemplate.postForObject(new URI(SERVICE_URI), warehouseInsertRequest, Object.class);
        Warehouse warehouseInsertActual = null;
        Optional<Warehouse> optionalWarehouse = warehouseRestRepository.findById(warehouseInsertExpected.getMdmId());
        if (optionalWarehouse.isPresent())
            warehouseInsertActual = optionalWarehouse.get();
        Assert.assertEquals(warehouseInsertExpected, warehouseInsertActual);

        Warehouse warehouseUpdateExpected = objectMapper.readValue(warehouseUpdateRequest, Warehouse.class);
        restTemplate.postForObject(new URI(SERVICE_URI), warehouseUpdateRequest, Object.class);

        Warehouse warehouseUpdateActual = null;
        optionalWarehouse = warehouseRestRepository.findById(warehouseUpdateExpected.getMdmId());
        if (optionalWarehouse.isPresent())
            warehouseUpdateActual = optionalWarehouse.get();
        Assert.assertEquals(warehouseUpdateExpected, warehouseUpdateActual);
    }
}