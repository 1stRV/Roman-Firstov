
package ru.x5.markusdata.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.sql.Timestamp;

@Entity
@Data
public class Gtins {

    @Id
    @Column(nullable = false)
    private String gtin;

    private String isMain;

    @Column(nullable = false)
    private String pluId;

    private String barCodeType;

    private String isTabacco;

    private String tabaccoMrc;

    private String tabaccoDateMrc;

    @Column(nullable = false)
    private Timestamp lastModDate;

    @Column(nullable = false)
    private String lastModUser;

    @Column(nullable = false)
    private Timestamp firstAddDate;
}