package ru.x5.markusdata.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sun.xml.internal.bind.v2.model.core.ID;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;
import java.util.UUID;

@Entity
@Data
public class Item {

    @Id
    @Column(nullable = false,length = 18)
    private String pluId;

    @Column(nullable = false,length = 132)
    private String fullname;

    @Column()
    private String unitsInPackaging;

    @Column(nullable = false)
    private String packageId;

    @Column(nullable = false)
    private String packageChId;

    private String packageLevel;

    private String amountInPackaging;

    @Column(nullable = false)
    private Timestamp lastModDate;

    @Column(nullable = false)
    private String lastModUser;

    @Column(nullable = false)
    private Timestamp firstAddDate;
}