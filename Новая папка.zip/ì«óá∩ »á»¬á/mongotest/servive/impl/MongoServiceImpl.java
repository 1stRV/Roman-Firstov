package ru.x5.mongotest.servive.impl;

import com.mongodb.BulkWriteOperation;
import com.mongodb.client.MongoDatabase;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import ru.x5.mongotest.exception.CisDoesNotExistException;
import ru.x5.mongotest.exception.ProductDoesNotExistException;
import ru.x5.mongotest.model.*;
import ru.x5.mongotest.repository.*;
import ru.x5.mongotest.servive.MongoService;
import ru.x5.mongotest.type.EnumPackageType;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class MongoServiceImpl implements MongoService {
    private final ProductRepository productRepository;
    private final CisPackRepository cisPackRepository;
    private final CisBlockRepository cisBlockRepository;
    private final CisBoxRepository cisBoxRepository;
    private final CisPalletRepository cisPalletRepository;
    private final MongoTemplate mongoTemplate;

    @Override
    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    @Override
    public CisPack createCisPack(CisPack cisPack) {
        return cisPackRepository.save(cisPack);
    }

    @Override
    public CisBlock createCisBlock(CisBlock cisBlock) {
        return cisBlockRepository.save(cisBlock);
    }

    @Override
    public CisBox createCisBox(CisBox cisBox) {
        return cisBoxRepository.save(cisBox);
    }

    @Override
    public CisPallet createCisPallet(CisPallet cisPallet) {
        return cisPalletRepository.save(cisPallet);
    }

    @Override
    public Product findProductById(String id) {
        return productRepository.findById(id).orElseThrow(() -> new ProductDoesNotExistException("Продукт с id = " + id + " не найден в БД!"));
    }

    @Override
    public CisPack findCisPackByCisId(String cisId) {
        return cisPackRepository.findById(cisId).orElseThrow(() -> new CisDoesNotExistException("CisPack с cisId = " + cisId + " не найден в БД"));
    }

    @Override
    public CisBlock findCisBlockByCisId(String cisId) {
        return cisBlockRepository.findById(cisId).orElseThrow(() -> new CisDoesNotExistException("CisBlock с cisId = " + cisId + " не найден в БД!"));
    }

    @Override
    public CisBox findCisBoxByCisId(String cisId) {
        return cisBoxRepository.findById(cisId).orElseThrow(() -> new CisDoesNotExistException("CisBox с cisId = " + cisId + " не найден в БД!"));
    }

    @Override
    public CisPallet findCisPalletByCisId(String cisId) {
        return cisPalletRepository.findById(cisId).orElseThrow(() -> new CisDoesNotExistException("CisPallet с cisId = " + cisId + " не найден в БД!"));
    }

    @Override
    public List<CisPack> findCisPackBySapHeaderId(String sapHeaderId) {
        List<CisPack> list = mongoTemplate.find(new Query(Criteria.where("sapHeaderId").is(sapHeaderId)), CisPack.class);
        if (!list.isEmpty()) {
            return list;
        } else {
            throw new CisDoesNotExistException("CisPack с sapHeaderId = " + sapHeaderId + " не найден в БД!");
        }
    }

    @Override
    public List<CisBlock> findCisBlockBySapHeaderId(String sapHeaderId) {
        List<CisBlock> list = mongoTemplate.find(new Query(Criteria.where("sapHeaderId").is(sapHeaderId)), CisBlock.class);
        if (!list.isEmpty()) {
            return list;
        } else {
            throw new CisDoesNotExistException("CisBlock с sapHeaderId = " + sapHeaderId + " не найден в БД!");
        }
    }

    @Override
    public List<CisBox> findCisBoxBySapHeaderId(String sapHeaderId) {
        List<CisBox> list = mongoTemplate.find(new Query(Criteria.where("sapHeaderId").is(sapHeaderId)), CisBox.class);
        if (!list.isEmpty()) {
            return list;
        } else {
            throw new CisDoesNotExistException("CisBox с sapHeaderId = " + sapHeaderId + " не найден в БД!");
        }
    }

    @Override
    public List<CisPallet> findCisPalletBySapHeaderId(String sapHeaderId) {
        List<CisPallet> list = mongoTemplate.find(new Query(Criteria.where("sapHeaderId").is(sapHeaderId)), CisPallet.class);
        if (!list.isEmpty()) {
            return list;
        } else {
            throw new CisDoesNotExistException("CisPallet с sapHeaderId = " + sapHeaderId + " не найден в БД!");
        }
    }

    @Override
    public void updateStatusCisPack(CisPack cisPack) {
        CisPack cisPackDB = mongoTemplate.findOne(
                Query.query(Criteria.where("_id").is(cisPack.getCisId())), CisPack.class);
        if (cisPackDB != null) {
            cisPackDB.setStatus(cisPack.getStatus());
            mongoTemplate.save(cisPackDB, "CisPack");
        } else {
            throw new CisDoesNotExistException("CisPack с cisId = " + cisPack.getCisId() + " не найден в БД!");
        }
    }

    @Override
    public void updateStatusOfCisPackAndParents(CisPack cisPack) {
        CisPack cisPackDB = mongoTemplate.findOne(
                Query.query(Criteria.where("_id").is(cisPack.getCisId())), CisPack.class);
        if (cisPackDB != null) {
            cisPackDB.setStatus(cisPack.getStatus());
            mongoTemplate.save(cisPackDB, "CisPack");

            CisBlock cisBlockDB = mongoTemplate.findOne(
                    Query.query(Criteria.where("_id").is(cisPackDB.getParentCisBlock().getCisId())), CisBlock.class);
            if (cisBlockDB != null) {
                cisBlockDB.setStatus("disaggregation");
                mongoTemplate.save(cisBlockDB, "CisBlock");

                CisBox cisBoxDB = mongoTemplate.findOne(
                        Query.query(Criteria.where("_id").is(cisBlockDB.getParentCisBox().getCisId())), CisBox.class);
                if (cisBoxDB != null) {
                    cisBoxDB.setStatus("disaggregation");
                    mongoTemplate.save(cisBoxDB, "CisBox");

                    CisPallet cisPalletDB = mongoTemplate.findOne(
                            Query.query(Criteria.where("_id").is(cisBoxDB.getParentCisPallet().getCisId())), CisPallet.class);
                    if (cisPalletDB != null) {
                        cisPalletDB.setStatus("disaggregation");
                        mongoTemplate.save(cisPalletDB, "CisPallet");
                    } else {
                        throw new CisDoesNotExistException("CisPallet с cisId = " + cisBoxDB.getParentCisPallet().getCisId() + " не найден в БД!");
                    }
                } else {
                    throw new CisDoesNotExistException("CisBox с cisId = " + cisBlockDB.getParentCisBox().getCisId() + " не найден в БД!");
                }
            } else {
                throw new CisDoesNotExistException("CisBlock с cisId = " + cisPackDB.getParentCisBlock().getCisId() + " не найден в БД!");
            }
        } else {
            throw new CisDoesNotExistException("CisPack с cisId = " + cisPack.getCisId() + " не найден в БД!");
        }
    }

    @Override
    public void updateSapHeaderIdCisPack(CisPack cisPack) {
        CisPack cisPackDB = mongoTemplate.findOne(
                Query.query(Criteria.where("_id").is(cisPack.getCisId())), CisPack.class);
        if (cisPackDB != null) {
            cisPackDB.setSapHeaderId(cisPack.getSapHeaderId());
            mongoTemplate.save(cisPackDB, "CisPack");
        } else {
            throw new CisDoesNotExistException("CisPack с cisId = " + cisPack.getCisId() + " не найден в БД!");
        }
    }

    @Override
    public void updateSapDetailIdCisPack(CisPack cisPack) {
        CisPack cisPackDB = mongoTemplate.findOne(
                Query.query(Criteria.where("_id").is(cisPack.getCisId())), CisPack.class);
        if (cisPackDB != null) {
            cisPackDB.setSapDetailId(cisPack.getSapDetailId());
            mongoTemplate.save(cisPackDB, "CisPack");
        } else {
            throw new CisDoesNotExistException("CisPack с cisId = " + cisPack.getCisId() + " не найден в БД!");
        }
    }

    @Override
    public void createCisPalletBoxBlockPack() {
        List<CisPack> cisPacks1 = new ArrayList<>();

//        for (int f = 0; f < 24325; f++) {
//            String randomCisPalletId = RandomStringUtils.randomAlphanumeric(32);
//            String randomCisPalletStatus = RandomStringUtils.randomAlphanumeric(32);
//            String randomCisPalletSapHeaderId = RandomStringUtils.randomAlphanumeric(32);
//            String randomCisPalletSapDetailId = RandomStringUtils.randomAlphanumeric(32);
//            CisPallet cisPallet = new CisPallet(randomCisPalletId, EnumPackageType.PALLET, randomCisPalletStatus, randomCisPalletSapHeaderId, randomCisPalletSapDetailId);
//            cisPallets1.add(cisPallet);
//
//
//        }
//        cisPalletRepository.insert(cisPallets1);

        for (int f = 0; f < 24325; f++) {

            String randomCisPackId = RandomStringUtils.randomAlphanumeric(32);
            String randomCisPackStatus = RandomStringUtils.randomAlphanumeric(32);
            String randomCisPackSapHeaderId = RandomStringUtils.randomAlphanumeric(32);
            String randomCisPackSapDetailId = RandomStringUtils.randomAlphanumeric(32);
            CisPack cisPack = CisPack.builder().cisId(randomCisPackId).packageType(EnumPackageType.PACK).status(randomCisPackStatus).sapHeaderId(randomCisPackSapHeaderId).sapDetailId(randomCisPackSapDetailId).parentCisBlock(cisBlock).build();
            cisPacks1.add(cisPack);


        }
        cisPackRepository.insert(cisPacks1);
//        List<CisPallet> cisPallets1 = new ArrayList<>();
//        List<CisBox> cisBoxes1 = new ArrayList<>();
//        List<CisBlock> cisBlocks1 = new ArrayList<>();
//        List<CisPack> cisPacks1 = new ArrayList<>();
//
//        List<CisPallet> cisPallets2 = new ArrayList<>();
//        List<CisBox> cisBoxes2 = new ArrayList<>();
//        List<CisBlock> cisBlocks2 = new ArrayList<>();
//        List<CisPack> cisPacks2 = new ArrayList<>();
//
//        List<CisPallet> cisPallets3 = new ArrayList<>();
//        List<CisBox> cisBoxes3 = new ArrayList<>();
//        List<CisBlock> cisBlocks3 = new ArrayList<>();
//        List<CisPack> cisPacks3 = new ArrayList<>();
//
//        List<CisPallet> cisPallets4 = new ArrayList<>();
//        List<CisBox> cisBoxes4 = new ArrayList<>();
//        List<CisBlock> cisBlocks4 = new ArrayList<>();
//        List<CisPack> cisPacks4 = new ArrayList<>();
//
//
//
//        for (int f = 0; f < 100; f++) {
//            for (int i = 0; i < 38; i++) {
//                String randomCisPalletId = RandomStringUtils.randomAlphanumeric(32);
//                String randomCisPalletStatus = RandomStringUtils.randomAlphanumeric(32);
//                String randomCisPalletSapHeaderId = RandomStringUtils.randomAlphanumeric(32);
//                String randomCisPalletSapDetailId = RandomStringUtils.randomAlphanumeric(32);
//                CisPallet cisPallet = new CisPallet(randomCisPalletId, EnumPackageType.PALLET, randomCisPalletStatus, randomCisPalletSapHeaderId, randomCisPalletSapDetailId);
//                cisPallets1.add(cisPallet);
//
//                if(cisPallets1.size()>31037849){
//                    cisPalletRepository.insert(cisPallets1);
//                }
//
//
//                for (int j = 0; j < 25; j++) {
//                    String randomCisBoxStatus = RandomStringUtils.randomAlphanumeric(29);
//                    String randomCisBoxSapHeaderId = RandomStringUtils.randomAlphanumeric(29);
//                    String randomCisBoxSapDetailId = RandomStringUtils.randomAlphanumeric(29);
//                    String randomCisBoxId = RandomStringUtils.randomAlphanumeric(29);
//                    CisBox cisBox = CisBox.builder().cisId(randomCisBoxId).packageType(EnumPackageType.BOX).status(randomCisBoxStatus).sapHeaderId(randomCisBoxSapHeaderId).sapDetailId(randomCisBoxSapDetailId).parentCisPallet(cisPallet).build();
//                    cisBoxes1.add(cisBox);
//
//                    if(cisPallets1.size()>43432){
//                        cisPalletRepository.insert(cisBoxes1);
//                    }
//                    for (int k = 0; k < 50; k++) {
//                        String randomCisBlockId = RandomStringUtils.randomAlphanumeric(31);
//                        String randomCisBlockStatus = RandomStringUtils.randomAlphanumeric(31);
//                        String randomCisBlockSapHeaderId = RandomStringUtils.randomAlphanumeric(31);
//                        String randomCisBlockSapDetailId = RandomStringUtils.randomAlphanumeric(31);
//                        CisBlock cisBlock = CisBlock.builder().cisId(randomCisBlockId).packageType(EnumPackageType.BLOCK).status(randomCisBlockStatus).sapHeaderId(randomCisBlockSapHeaderId).sapDetailId(randomCisBlockSapDetailId).parentCisBox(cisBox).build();
//                        cisBlocks1.add(cisBlock);
//
//                        if(cisBlocks1.size()>43432){
//                            cisPalletRepository.insert(cisBlocks1);
//                        }
//                        for (int l = 0; l < 10; l++) {
//                            String randomCisPackStatus = RandomStringUtils.randomAlphanumeric(50);
//                            String randomCisPackSapHeaderId = RandomStringUtils.randomAlphanumeric(50);
//                            String randomCisPackSapDetailId = RandomStringUtils.randomAlphanumeric(50);
//                            String randomCisPackId = RandomStringUtils.randomAlphanumeric(50);
//                            CisPack cisPack = CisPack.builder().cisId(randomCisPackId).packageType(EnumPackageType.PACK).status(randomCisPackStatus).sapHeaderId(randomCisPackSapHeaderId).sapDetailId(randomCisPackSapDetailId).parentCisBlock(cisBlock).build();
//                            cisPacks1.add(cisPack);
//                        }
//                    }
//                }
//            }
//        }
//
//        cisBoxRepository.insert(cisBoxes1);
//        cisBlockRepository.insert(cisBlocks1);
//        cisPackRepository.insert(cisPacks1);
//        cisPalletRepository.insert(cisPallets1);
//
//        cisBoxRepository.insert(cisBoxes2);
//        cisBlockRepository.insert(cisBlocks2);
//        cisPackRepository.insert(cisPacks2);
//        cisPalletRepository.insert(cisPallets2);
//
//        cisBoxRepository.insert(cisBoxes3);
//        cisBlockRepository.insert(cisBlocks3);
//        cisPackRepository.insert(cisPacks3);
//        cisPalletRepository.insert(cisPallets3);
//
//        cisBoxRepository.insert(cisBoxes4);
//        cisBlockRepository.insert(cisBlocks4);
//        cisPackRepository.insert(cisPacks4);
//        cisPalletRepository.insert(cisPallets4);
    }


}

//    @Override
//    public void createCisPalletBoxBlockPack() {
//        for (int f = 0; f < 100; f++) {
//            for (int i = 0; i < 38; i++) {
//                String randomCisPalletId = RandomStringUtils.randomAlphanumeric(32);
//                String randomCisPalletStatus = RandomStringUtils.randomAlphanumeric(32);
//                String randomCisPalletSapHeaderId = RandomStringUtils.randomAlphanumeric(32);
//                String randomCisPalletSapDetailId = RandomStringUtils.randomAlphanumeric(32);
//                CisPallet cisPallet = new CisPallet(randomCisPalletId, EnumPackageType.PALLET, randomCisPalletStatus, randomCisPalletSapHeaderId, randomCisPalletSapDetailId);
//                cisPalletRepository.save(cisPallet);
//
//                for (int j = 0; j < 25; j++) {
//                    String randomCisBoxStatus = RandomStringUtils.randomAlphanumeric(29);
//                    String randomCisBoxSapHeaderId = RandomStringUtils.randomAlphanumeric(29);
//                    String randomCisBoxSapDetailId = RandomStringUtils.randomAlphanumeric(29);
//                    String randomCisBoxId = RandomStringUtils.randomAlphanumeric(29);
//
//                    CisBox cisBox = CisBox.builder().cisId(randomCisBoxId).packageType(EnumPackageType.BOX).status(randomCisBoxStatus).sapHeaderId(randomCisBoxSapHeaderId).sapDetailId(randomCisBoxSapDetailId).parentCisPallet(cisPallet).build();
//                    cisBoxRepository.save(cisBox);
//                    for (int k = 0; k < 50; k++) {
//                        String randomCisBlockId = RandomStringUtils.randomAlphanumeric(31);
//                        String randomCisBlockStatus = RandomStringUtils.randomAlphanumeric(31);
//                        String randomCisBlockSapHeaderId = RandomStringUtils.randomAlphanumeric(31);
//                        String randomCisBlockSapDetailId = RandomStringUtils.randomAlphanumeric(31);
//
//                        CisBlock cisBlock = CisBlock.builder().cisId(randomCisBlockId).packageType(EnumPackageType.BLOCK).status(randomCisBlockStatus).sapHeaderId(randomCisBlockSapHeaderId).sapDetailId(randomCisBlockSapDetailId).parentCisBox(cisBox).build();
//                        cisBlockRepository.save(cisBlock);
//                        for (int l = 0; l < 10; l++) {
//                            String randomCisPackStatus = RandomStringUtils.randomAlphanumeric(50);
//                            String randomCisPackSapHeaderId = RandomStringUtils.randomAlphanumeric(50);
//                            String randomCisPackSapDetailId = RandomStringUtils.randomAlphanumeric(50);
//                            String randomCisPackId = RandomStringUtils.randomAlphanumeric(50);
//
//                            CisPack cisPack = CisPack.builder().cisId(randomCisPackId).packageType(EnumPackageType.PACK).status(randomCisPackStatus).sapHeaderId(randomCisPackSapHeaderId).sapDetailId(randomCisPackSapDetailId).parentCisBlock(cisBlock).build();
//                            cisPackRepository.save(cisPack);
//                        }
//                    }
//                }
//            }
//        }
//    }

//    @Override
//    public void updateStatusOfCisPalletAndDescendants(CisPallet cisPallet) {
//        CisPallet cisPalletDB = mongoTemplate.findOne(
//                Query.query(Criteria.where("_id").is(cisPallet.getCisId())), CisPallet.class);
//        if (cisPalletDB != null) {
//            cisPalletDB.setStatus(cisPallet.getStatus());
//            mongoTemplate.save(cisPallet, "CisPallet");
//
//            CisBox cisBoxDB = mongoTemplate.findOne(
//                    Query.query(Criteria.where("_id").is(cisPalletDB.getDescendantCisBox())), CisBox.class);
//            if (cisBoxDB != null) {
//                cisBoxDB.setStatus("disaggregation");
//                mongoTemplate.save(cisBoxDB, "CisBox");
//            } else {
//                throw new CisDoesNotExistException("CisBox с cisId = " + cisPalletDB.getDescendantCisBox().getCisId() + " не найден в БД!");
//            }
//            CisBlock cisBlockDB = mongoTemplate.findOne(
//                    Query.query(Criteria.where("_id").is(cisBoxDB.getDescendantCisBlock())), CisBlock.class);
//            if (cisBlockDB != null) {
//                cisBlockDB.setStatus("disaggregation");
//                mongoTemplate.save(cisBlockDB, "CisBlock");
//            } else {
//                throw new CisDoesNotExistException("CisBlock с cisId = " + cisBoxDB.getDescendantCisBlock().getCisId() + " не найден в БД!");
//            }
//            CisPack cisPackDB = mongoTemplate.findOne(
//                    Query.query(Criteria.where("_id").is(cisBlockDB.getDescendantCisPack())), CisPack.class);
//            if (cisPackDB != null) {
//                cisPackDB.setStatus("disaggregation");
//                mongoTemplate.save(cisPackDB, "CisPack");
//            } else {
//                throw new CisDoesNotExistException("CisPack с cisId = " + cisBlockDB.getDescendantCisPack().getCisId() + " не найден в БД!");
//            }
//        } else {
//            throw new CisDoesNotExistException("CisPallet с cisId = " + cisPallet.getCisId() + " не найден в БД!");
//        }
//    }