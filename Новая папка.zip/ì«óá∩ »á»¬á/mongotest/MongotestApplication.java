package ru.x5.mongotest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongotestApplication {
    public static void main(String[] args) {
        SpringApplication.run(MongotestApplication.class, args);
    }
}
