package ru.x5.markusdata.service.impl;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.repository.ItemRestRepository;
import ru.x5.markusdata.service.ItemService;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ItemServiceImpl implements ItemService {

    private final ItemRestRepository itemRestRepository;
    private ModelMapper modelMapper = new ModelMapper();

    @Override
    public Item saveItem(ItemDTO itemDTO) {
        return itemRestRepository.save(convertDTOToEntity(itemDTO));
    }

    @Override
    public List<Item> findAllItem() {
        return itemRestRepository.findAll();
    }

    private Item convertDTOToEntity(ItemDTO itemDTO) {
        return modelMapper.map(itemDTO, Item.class);
    }
}
