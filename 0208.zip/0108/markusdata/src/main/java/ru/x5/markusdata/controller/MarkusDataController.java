package ru.x5.markusdata.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.x5.markusdata.entity.dto.ItemDTO;
import ru.x5.markusdata.entity.jpa.Gtins;
import ru.x5.markusdata.entity.jpa.Item;
import ru.x5.markusdata.service.GtinsService;
import ru.x5.markusdata.service.ItemService;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class MarkusDataController {

    private final ItemService itemService;
    private final GtinsService gtinsService;

    @PostMapping(value = "/item")
    public Item saveItem(@RequestBody ItemDTO itemDTO) {
        return itemService.saveItem(itemDTO);
    }

    @GetMapping(value = "/items")
    public List<Item> findAllItem() {
        return itemService.findAllItem();
    }

    @GetMapping(value = "/gtins")
    public List<Gtins> findAllGtins() {
        return gtinsService.findAllGtins();
    }
}