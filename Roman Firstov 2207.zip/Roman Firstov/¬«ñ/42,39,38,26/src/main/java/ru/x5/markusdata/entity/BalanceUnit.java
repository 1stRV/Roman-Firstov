package ru.x5.markusdata.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.sql.Timestamp;

@Entity
@Data
public class BalanceUnit {

    @Id
    private String mdmId;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String inn;

    @Column(nullable = false)
    private Timestamp lastModDate;

    @Column(nullable = false)
    private String lastModUser;

    @Column(nullable = false)
    private Timestamp firstAddDate;
}

