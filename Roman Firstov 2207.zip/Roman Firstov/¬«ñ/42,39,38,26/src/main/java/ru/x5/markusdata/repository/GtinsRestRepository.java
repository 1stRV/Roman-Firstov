package ru.x5.markusdata.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import ru.x5.markusdata.entity.Gtins;

@RepositoryRestResource(path = "gtins")
interface GtinsRestRepository extends JpaRepository<Gtins, String> {
}
