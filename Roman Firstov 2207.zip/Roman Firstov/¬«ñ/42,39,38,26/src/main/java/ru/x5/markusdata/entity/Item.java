package ru.x5.markusdata.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(nullable = false)
    @JsonProperty("PLU_ID")
    private String pluId;

    @Column(nullable = false)
    @JsonProperty("FULLNAME")
    private String fullname;

    @JsonProperty("UNITS_IN_PACKAGING")
    private String unitsInPackaging;

    @Column(nullable = false)
    @JsonProperty("PACKAGE_ID")
    private String packageId;

    @Column(nullable = false)
    @JsonProperty("PACKAGE_CH_ID")
    private String packageChId;

    @JsonProperty("PACKAGE_LEVEL")
    private String packageLevel;

    @JsonProperty("AMOUNT_IN_PACKAGING")
    private String amountInPackaging;

    @Column(nullable = false)
    @JsonProperty("LAST_MOD_DATE")
    private Timestamp lastModDate;

    @Column(nullable = false)
    @JsonProperty("LAST_MOD_USER")
    private String lastModUser;

    @Column(nullable = false)
    @JsonProperty("FIRST_ADD_DATE")
    private Timestamp firstAddDate;
}