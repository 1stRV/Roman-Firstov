package ru.x5.markusdata.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;

@Entity
@Data
public class BalanceUnit {

    @Id
    @Column(nullable = false, length = 5)
    private String mdmId;

    @Column(nullable = false, length = 255)
    private String name;

    @Column(nullable = false, length = 12)
    private String inn;

    @Column(nullable = false)
    private Timestamp lastModDate;

    @Column(nullable = false)
    private String lastModUser;

    @Column(nullable = false)
    private Timestamp firstAddDate;
}

