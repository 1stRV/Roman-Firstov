
package ru.x5.markusdata.entity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.sql.Timestamp;

@Entity
@Data
public class Gtins {

    @Id
    @Column(nullable = false,length = 18)
    private String gtin;

    @Column(nullable = false, length = 10)
    private String isMain;

    @Column(nullable = false, length = 18)
    private String pluId;

    @Column(nullable = false, length = 255)
    private String barCodeType;

    @Column(nullable = false, length = 10)
    private String isTabacco;

    @Column(nullable = false, length = 7)
    private String tabaccoMrc;

    private String tabaccoDateMrc;

    @Column(nullable = false)
    private Timestamp lastModDate;

    @Column(nullable = false)
    private String lastModUser;

    @Column(nullable = false)
    private Timestamp firstAddDate;
}