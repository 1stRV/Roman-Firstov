package ru.x5.markusdata.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Data
public class Warehouse {

    @Id
    @Column(nullable = false, length = 5)
    private String mdmId;

    @Column(nullable = false, length = 255)
    private String name;

    //    @ManyToOne
//    @JoinColumn(name = "balanceUnit", referencedColumnName = "mdmId", nullable = false)
    private BalanceUnit balanceUnit;

    @Column(nullable = false, length = 12)
    private String inn;

    @Column(length = 9)
    private String kpp;

    @Column(length = 10)
    private String isNoTobacco;

    @Column(nullable = false)
    private Timestamp lastModDate;

    @Column(nullable = false)
    private String lastModUser;

    @Column(nullable = false)
    private Timestamp firstAddDate;
}


