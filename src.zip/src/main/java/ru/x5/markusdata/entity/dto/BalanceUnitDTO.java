package ru.x5.markusdata.entity.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class BalanceUnitDTO implements Serializable {

    @JsonProperty(value = "MDM_ID")
    private String mdmId;

    @JsonProperty(value = "NAME")
    private String name;

    @JsonProperty(value = "INN")
    private String inn;
}