package ru.x5.markusdata.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "x5.markus.markusdata.swagger")
@Data
public class SwaggerProperties {
    private String title;
    private String description;
}
