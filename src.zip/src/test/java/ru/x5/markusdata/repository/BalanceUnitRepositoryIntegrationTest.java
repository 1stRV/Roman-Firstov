package ru.x5.markusdata.repository;

import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.x5.markusdata.entity.dto.BalanceUnitDTO;
import ru.x5.markusdata.entity.jpa.BalanceUnit;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class BalanceUnitRepositoryIntegrationTest extends AbstractRepositoryTest {

    @Autowired
    private BalanceUnitRepository balanceUnitRestRepository;

    @Value("classpath:json/balance-unit.json")
    private Resource balanceUnitInsertRequestResource;

    @Value("classpath:json/balance-unit-change.json")
    private Resource balanceUnitUpdateRequestResource;

    @Value("classpath:json/balance-unit-long-field.json")
    private Resource balanceUnitLongFieldRequestResource;

    @Value("classpath:json/balance-unit-null-name-field.json")
    private Resource balanceUnitNullFieldRequestResource;

    private String balanceUnitInsertRequest;

    private String balanceUnitUpdateRequest;

    private String balanceUnitLongFieldRequest;

    private String balanceUnitNullFieldRequest;

    @Before
    public void init() throws IOException {
        balanceUnitInsertRequest = IOUtils.toString(balanceUnitInsertRequestResource.getInputStream(), StandardCharsets.UTF_8);
        balanceUnitUpdateRequest = IOUtils.toString(balanceUnitUpdateRequestResource.getInputStream(), StandardCharsets.UTF_8);
        balanceUnitLongFieldRequest = IOUtils.toString(balanceUnitLongFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
        balanceUnitNullFieldRequest = IOUtils.toString(balanceUnitNullFieldRequestResource.getInputStream(), StandardCharsets.UTF_8);
    }

    @Test
    public void balanceUnitRepositoryInsert() throws Exception {
        BalanceUnitDTO balanceUnitInsertExpected = objectMapper.readValue(balanceUnitInsertRequest, BalanceUnitDTO.class);
        ResponseEntity responseEntity = restTemplate.postForEntity("/balanceUnit", balanceUnitInsertRequest, Object.class);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

        Optional<BalanceUnit> optionalBalanceUnit = balanceUnitRestRepository.findById(balanceUnitInsertExpected.getMdmId());
        assertTrue(optionalBalanceUnit.isPresent());
        Assertions.assertThat(balanceUnitInsertExpected).isEqualToIgnoringGivenFields(optionalBalanceUnit.get(), "LAST_MOD_DATE", "FIRST_ADD_DATE");
    }

    @Test
    public void balanceUnitRepositoryUpdate() throws Exception {
        restTemplate.postForEntity("/balanceUnit", balanceUnitInsertRequest, Object.class);

        BalanceUnitDTO balanceUnitUpdateExpected = objectMapper.readValue(balanceUnitUpdateRequest, BalanceUnitDTO.class);
        ResponseEntity responseEntityUpdate = restTemplate.postForEntity("/balanceUnit", balanceUnitUpdateRequest, Object.class);
        assertEquals(HttpStatus.OK, responseEntityUpdate.getStatusCode());

        Optional<BalanceUnit> optionalBalanceUnit = balanceUnitRestRepository.findById(balanceUnitUpdateExpected.getMdmId());
        assertTrue(optionalBalanceUnit.isPresent());
        Assertions.assertThat(balanceUnitUpdateExpected).isEqualToIgnoringGivenFields(optionalBalanceUnit.get(), "LAST_MOD_DATE", "FIRST_ADD_DATE");
    }

    @Test
    public void longFieldRequest() {
        ResponseEntity responseEntity = restTemplate.postForEntity("/balanceUnit", balanceUnitLongFieldRequest, Object.class);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }

    @Test
    public void nullFieldRequest() {
        ResponseEntity responseEntity = restTemplate.postForEntity("/balanceUnit", balanceUnitNullFieldRequest, Object.class);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    }
}